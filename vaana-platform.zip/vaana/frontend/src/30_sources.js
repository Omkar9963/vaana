/* ================= data sources =================
   Both sources expose the same interface:
     init()                      -> loads run information
     steps, upSteps, initMs, members, levels, rainProducts, chance, accum, hasStation, live, runLabel
     field(key, h, opt)          -> Promise<{a: Float32Array, g: grid, h?: hour actually shown}>
     wind(kind, h, lev)          -> Promise<{u, v, g, up}>
     storms                      -> [{basin, median:[[h,x,y,p,v]], tracks:[[[h,x,y,p,v]]]}]
     point(lon, lat)             -> Promise<{hours, stats:{t2,rain,ws}, now:[...], daily:[...], land}>
*/
const thrCode = t => String(t).replace('.', '');

/* ---------- live WeatherNext 3 data produced by the ingest job ---------- */
class RealSource {
  constructor(base) { this.base = base.replace(/\/$/, ''); this.live = true; this.cache = new Map(); }
  async init() {
    const r = await fetch(`${this.base}/latest.json`, { cache: 'no-cache' });
    if (!r.ok) throw new Error(`latest.json returned ${r.status}`);
    this.latest = await r.json();
    this.root = `${this.base}/runs/${this.latest.run}`;
    const m = await (await fetch(`${this.root}/meta.json`)).json();
    this.meta = m;
    this.steps = m.steps; this.upSteps = m.up_steps || []; this.initMs = Date.parse(m.init);
    this.members = m.members; this.levels = m.levels || []; this.rainProducts = m.rain_products || ['model'];
    this.chance = m.chance; this.accum = m.accum; this.hasStation = !!m.grids.stn;
    this.model = m.model || { name: 'WeatherNext 3', by: 'Google DeepMind', attribution: '' };
    this.stepHours = m.step_hours || 1;
    const lv = {}; for (const k of Object.keys(m.layers)) { const x = /^up_(\w)_(\d+)$/.exec(k); if (x) (lv[x[1]] = lv[x[1]] || new Set()).add(+x[2]); }
    this.levelsBy = Object.fromEntries(Object.entries(lv).map(([c, set]) => [c, [...set].sort((a, b) => b - a)]));
    const d = new Date(this.initMs);
    this.runLabel = `${d.getUTCDate()} ${MON[d.getUTCMonth()]} ${d.getUTCFullYear()}, ${pad(d.getUTCHours())}:00 UTC`;
    try { this.storms = (await (await fetch(`${this.root}/tracks.json`)).json()).storms || []; } catch (e) { this.storms = []; }
  }
  async grid(name, h) {
    const L = this.meta.layers[name]; if (!L) throw new Error(`Layer ${name} is not in this run`);
    return { a: await this.bin(`${this.root}/f/${name}/${h}.bin`, L.dt, L.scale, L.offset), g: this.meta.grids[L.grid] };
  }
  bin(url, dt, scale, offset) {
    if (this.cache.has(url)) { const p = this.cache.get(url); this.cache.delete(url); this.cache.set(url, p); return p; }
    const p = fetch(url).then(r => { if (!r.ok) throw new Error(`${r.status} for ${url}`); return r.arrayBuffer(); }).then(buf => {
      const T = dt === 'u8' ? Uint8Array : dt === 'u16' ? Uint16Array : Int16Array, S = dt === 'u8' ? 255 : dt === 'u16' ? 65535 : -32768;
      const raw = new T(buf), out = new Float32Array(raw.length);
      for (let k = 0; k < raw.length; k++) out[k] = raw[k] === S ? NaN : raw[k] * scale + offset;
      return out;
    });
    p.catch(() => this.cache.delete(url));
    this.cache.set(url, p);
    while (this.cache.size > 80) this.cache.delete(this.cache.keys().next().value);
    return p;
  }
  levelsFor(id) { const c = { uwind: 'u', utemp: 't', uz: 'z', uq: 'q', uw: 'w' }[id]; return (c && this.levelsBy[c]) || []; }
  fileLayer(key, o) {
    const up = { uwind: 'u', utemp: 't', uz: 'z', uq: 'q', uw: 'w' }[key];
    if (up) return `up_${up}_${o.lev}`;
    return ({ rain: 'rain_' + o.prod, accum: 'accum' + o.per, chance: 'chance_' + thrCode(o.thr), wind10: 'ws10', wind100: 'ws100',
      t2: o.res === 'station' && this.hasStation ? 't2s' : 't2', td2: o.res === 'station' && this.hasStation ? 'td2s' : 'td2' })[key] || key;
  }
  upHour(h) { let best = this.upSteps[0]; for (const s of this.upSteps) if (s <= h) best = s; return best; }
  async field(key, h, o) {
    const combine = async (names, fn, hh = h) => {
      const gs = await Promise.all(names.map(n => this.grid(n, hh))), n = gs[0].a.length, a = new Float32Array(n);
      for (let k = 0; k < n; k++) a[k] = fn(...gs.map(x => x.a[k]));
      return { a, g: gs[0].g, h: hh };
    };
    switch (key) {
      case 'rain': return this.grid('rain_' + o.prod, h);
      case 'accum': return this.grid('accum' + o.per, h);
      case 'chance': return this.grid('chance_' + thrCode(o.thr), h);
      case 'wind10': return this.grid('ws10', h);
      case 'wind100': return this.grid('ws100', h);
      case 't2': case 'td2': return this.grid(o.res === 'station' && this.hasStation ? key + 's' : key, h);
      case 'rh': return combine(['t2', 'td2'], rhOf);
      case 'feels': return combine(['t2', 'td2', 'ws10'], (t, d, w) => feelsOf(t, rhOf(t, d), w));
      case 'strike': return { a: await this.bin(`${this.root}/strike.bin`, 'u8', 1, 0), g: this.meta.grids.strk };
      case 'uwind': return combine([`up_u_${o.lev}`, `up_v_${o.lev}`], Math.hypot, this.upHour(h));
      case 'utemp': case 'uz': case 'uq': case 'uw': { const hh = this.upHour(h); const r = await this.grid(`up_${{ utemp: 't', uz: 'z', uq: 'q', uw: 'w' }[key]}_${o.lev}`, hh); r.h = hh; return r; }
      default: return this.grid(key, h);
    }
  }
  async wind(kind, h, lev) {
    if (kind === 'up' && !this.meta.layers[`up_u_${lev}`]) kind = '10';
    if (kind === 'up') { const hh = this.upHour(h); const [u, v] = await Promise.all([this.grid(`up_u_${lev}`, hh), this.grid(`up_v_${lev}`, hh)]); return { u: u.a, v: v.a, g: u.g, up: true }; }
    const s = kind === '100' && this.meta.layers.u100 ? '100' : '10';
    const [u, v] = await Promise.all([this.grid('u' + s, h), this.grid('v' + s, h)]);
    return { u: u.a, v: v.a, g: u.g };
  }
  prefetch(names, h) { for (const n of names) if (this.meta.layers[n]) this.grid(n, h).catch(() => {}); }
  async point(lon, lat) {
    const g = this.meta.grids.sfc, B = this.meta.block, i = Math.round((lon - g.lon0) / g.d), j = Math.round((g.lat1 - lat) / g.d);
    if (i < 0 || j < 0 || i >= g.nx || j >= g.ny) return null;
    const bi = Math.floor(i / B.cells), bj = Math.floor(j / B.cells), bw = Math.min(B.cells, g.nx - bi * B.cells), bh = Math.min(B.cells, g.ny - bj * B.cells);
    const r = await fetch(`${this.root}/pt/${bj}_${bi}.bin`); if (!r.ok) throw new Error('Point data missing');
    const raw = new Int16Array(await r.arrayBuffer()), cell = (j - bj * B.cells) * bw + (i - bi * B.cells), area = bw * bh;
    const ns = B.nsteps, nd = B.ndays, vi = Object.fromEntries(B.vars.map((n, k) => [n, k]));
    const get = (name, s) => { const k = vi[name], v = raw[(k * ns + s) * area + cell]; return v === -32768 ? NaN : v * B.scales[k]; };
    const dbase = B.vars.length * ns * area, dget = (k, d) => { const v = raw[dbase + (k * nd + d) * area + cell]; return v === -32768 ? NaN : v * B.dscales[k]; };
    const hours = this.steps, stats = { t2: [], rain: [], ws: [] }, now = [];
    for (let s = 0; s < ns; s++) {
      stats.t2.push([get('t2_10', s), get('t2_50', s), get('t2_90', s)]);
      stats.rain.push([get('rain_10', s), get('rain_50', s), get('rain_90', s)]);
      stats.ws.push([get('ws_10', s), get('ws_50', s), get('ws_90', s)]);
      now.push({ t2: get('t2_50', s), td2: get('td2', s), rain: get('rain_50', s), u10: get('u10', s), v10: get('v10', s),
        ws100: get('ws100', s), mslp: get('mslp', s), tcc: get('tcc', s) / 100, ghi: get('ghi', s), dir: get('dir', s) });
    }
    const daily = this.meta.days.map((d, k) => {
      let tx = -99, tn = 99, wx = 0;
      hours.forEach((h, s) => { if (h >= d.h0 - 1 && h <= d.h1) { tx = Math.max(tx, stats.t2[s][1]); tn = Math.min(tn, stats.t2[s][1]); wx = Math.max(wx, stats.ws[s][1]); } });
      return { day: d.label, tx, tn, wx, rain: dget(0, k), chance: Math.round(dget(1, k)), partial: d.partial };
    });
    return { hours, stats, now, daily, land: landAt(lon, lat) };
  }
}

/* ---------- built-in demo (simulated data, no downloads) ---------- */
class DemoSource {
  constructor() { this.live = false; }
  async init() {
    this.steps = Array.from({ length: HMAX + 1 }, (_, h) => h); this.upSteps = this.steps; this.initMs = Date.UTC(2026, 8, 24, 0, 0, 0);
    this.members = NM; this.levels = LEVS; this.rainProducts = ['model', 'imerg', 'exp']; this.chance = [2.5, 64.5, 115.6]; this.accum = [3, 24, 72];
    this.hasStation = true; this.runLabel = '24 Sep 2026, 00:00 UTC';
    this.model = { name: 'WeatherNext 3', by: 'Google DeepMind', attribution: '' }; this.stepHours = 1;
    this.storms = [{ basin: 'Bay of Bengal', median: TRACKS[0].map((s, h) => [h, s.x, s.y, 1007 - s.dp, s.v]),
      tracks: TRACKS.slice(1).map(tr => tr.map((s, h) => [h, s.x, s.y, 1007 - s.dp, s.v])) }];
  }
  levelsFor() { return LEVS; }
  fileLayer(key) { return key; }
  async field(key, t, o) {
    const s = getSfc(t), n = G.nx * G.ny;
    switch (key) {
      case 'rain': return { a: s[o.prod === 'model' ? 'rain' : o.prod], g: G };
      case 'accum': return { a: getAccum(t, o.per), g: G };
      case 'chance': return { a: getChance(t, o.thr), g: GC };
      case 'wind10': case 'wind100': { const u = key === 'wind10' ? s.u10 : s.u100, v = key === 'wind10' ? s.v10 : s.v100, a = new Float32Array(n); for (let k = 0; k < n; k++) a[k] = Math.hypot(u[k], v[k]); return { a, g: G }; }
      case 't2': case 'td2': return o.res === 'station' ? { a: getFine(t)[key], g: GF } : { a: s[key], g: G };
      case 'rh': { const a = new Float32Array(n); for (let k = 0; k < n; k++) a[k] = rhOf(s.t2[k], s.td2[k]); return { a, g: G }; }
      case 'feels': { const a = new Float32Array(n); for (let k = 0; k < n; k++) a[k] = feelsOf(s.t2[k], rhOf(s.t2[k], s.td2[k]), Math.hypot(s.u10[k], s.v10[k])); return { a, g: G }; }
      case 'sst': { const a = Float32Array.from(s.sst); for (let k = 0; k < n; k++) if (SG.L[k] > 0.5) a[k] = NaN; return { a, g: G }; }
      case 'uwind': { const U = getUpper(t, o.lev), a = new Float32Array(n); for (let k = 0; k < n; k++) a[k] = Math.hypot(U.u[k], U.v[k]); return { a, g: G }; }
      case 'utemp': return { a: getUpper(t, o.lev).T, g: G };
      case 'uz': return { a: getUpper(t, o.lev).Z, g: G };
      case 'uq': return { a: getUpper(t, o.lev).q, g: G };
      case 'uw': return { a: getUpper(t, o.lev).w, g: G };
      case 'strike': return { a: getStrike(), g: GC };
      default: return { a: s[key], g: G };
    }
  }
  async wind(kind, t, lev) {
    const s = getSfc(t);
    if (kind === 'up') { const U = getUpper(t, lev); return { u: U.u, v: U.v, g: G, up: true }; }
    return kind === '100' ? { u: s.u100, v: s.v100, g: G } : { u: s.u10, v: s.v10, g: G };
  }
  prefetch() {}
  async point(lon, lat) {
    const L = landAt(lon, lat), P = plat(lon, lat), E = elev(lon, lat, L, P), dry = dryf(lon, lat, P), det = (fbm(lon * 2.5 + 5, lat * 2.5 + 9, 0.5) - 0.5) * 2.4 * L;
    const nT = HMAX + 1, mem = { t2: [], rain: [], ws: [] }, now = [], o = {};
    for (let m = 0; m < NM; m++) {
      const a = { t2: new Float32Array(nT), rain: new Float32Array(nT), ws: new Float32Array(nT) };
      for (let t = 0; t < nT; t++) {
        sfc(lon, lat, t, TRACKS[m][t], m, L, E, dry, P, 0, o);
        a.t2[t] = o.t2 + det; a.rain[t] = o.rain; a.ws[t] = Math.hypot(o.u10, o.v10) * 3.6;
        if (m === 0) now.push({ ...o, t2: o.t2 + det, td2: o.td2 + det * 0.7, ws100: Math.hypot(o.u100, o.v100) * 3.6 });
      }
      for (const k in a) mem[k].push(a[k]);
    }
    const pct = (arrs, t) => { const v = arrs.map(a => a[t]).sort((x, y) => x - y); return [(v[1] + v[2]) / 2, (v[7] + v[8]) / 2, (v[13] + v[14]) / 2]; };
    const stats = {}; for (const k in mem) { stats[k] = []; for (let t = 0; t < nT; t++) stats[k].push(pct(mem[k], t)); }
    const days = []; let cur = null;
    for (let t = 1; t < nT; t++) {
      const d = new Date(this.initMs + (t - 0.5 + 5.5) * 3600e3), key = d.getUTCDate();
      if (!cur || cur.key !== key) { cur = { key, day: `${DAYS[d.getUTCDay()]} ${d.getUTCDate()}`, t0: t, t1: t }; days.push(cur); } else cur.t1 = t;
    }
    const daily = days.filter(d => d.t1 - d.t0 >= 11).map(d => {
      const tot = mem.rain.map(a => { let s = 0; for (let t = d.t0; t <= d.t1; t++) s += a[t]; return s; }).sort((x, y) => x - y);
      let tx = -99, tn = 99, wx = 0; for (let t = d.t0 - 1; t <= d.t1; t++) { tx = Math.max(tx, stats.t2[t][1]); tn = Math.min(tn, stats.t2[t][1]); wx = Math.max(wx, stats.ws[t][1]); }
      return { day: d.day, tx, tn, rain: (tot[7] + tot[8]) / 2, chance: Math.round(tot.filter(v => v >= 2.5).length / NM * 100), wx, partial: d.t1 - d.t0 < 23 };
    });
    return { hours: this.steps, stats, now, daily, land: L };
  }
}
