/* ================= layers ================= */
const R_RAIN = [[0.1, '#7fbfe6', .5], [1, '#3f93d6', .78], [2.5, '#2fb874', .85], [5, '#e9dc4c', .9], [7.6, '#f3a23a', .93], [15, '#e5513b', .95], [30, '#c42a7b', .97], [50, '#8a42d6', 1], [90, '#f1e4ff', 1]];
const R_ACC = [[1, '#8cc7e8', .5], [2.5, '#5aa9e0', .72], [15.6, '#2fb874', .85], [64.5, '#e9d24b', .9], [115.6, '#f08a3a', .95], [204.5, '#d63a3a', 1], [350, '#8f34c4', 1]];
const R_PCT = [[5, '#3a6fb0', .3], [25, '#3fa7c9', .55], [50, '#56c48a', .72], [70, '#f0c64a', .84], [90, '#e8563f', .94], [100, '#b3264f', 1]];
const R_WIND = [[0, '#27437a'], [3, '#2e70a8'], [6, '#2fa2a0'], [9, '#57b86b'], [12, '#bac94a'], [15, '#f0b43c'], [20, '#e8703a'], [25, '#d33b4a'], [33, '#a3317e'], [45, '#e7c4f0'], [60, '#ffffff']];
const R_TEMP = [[-30, '#5b2a86'], [-15, '#3c4fb3'], [0, '#3f8ed1'], [10, '#48b9c7'], [18, '#5cc28a'], [24, '#c7d155'], [28, '#f2c043'], [32, '#f08a36'], [36, '#e0503a'], [40, '#b3263f'], [46, '#7a1d4f']];
const R_UTEMP = [[-80, '#ece8ff'], [-60, '#8f6ad0'], [-45, '#4d58c0'], [-30, '#3f8ed1'], [-15, '#48b9c7'], [0, '#5cc28a'], [10, '#c7d155'], [20, '#f08a36'], [30, '#c3263f']];
const R_DEW = [[-20, '#8a6a4a'], [0, '#b59a64'], [10, '#d6c78a'], [16, '#8fcf8a'], [20, '#3fb07a'], [24, '#1f8f8a'], [27, '#1c5fa0'], [30, '#3b2f8f']];
const R_RH = [[10, '#a8743b'], [30, '#d8b56a'], [50, '#cfd78a'], [70, '#6cc18a'], [85, '#2f9fb0'], [100, '#2a4f9f']];
const R_P = [[960, '#6a2a8f'], [980, '#b3336b'], [995, '#e0703f'], [1002, '#e9c55a'], [1006, '#9fcf7a'], [1010, '#4fb3a8'], [1014, '#3f86c4'], [1020, '#35519c']];
const R_SST = [[24, '#3b5bb0'], [26, '#3f9fc9'], [27.5, '#5cc28a'], [28.5, '#e8d25a'], [29.5, '#f08a36'], [30.5, '#d33b3b'], [32, '#8a1d4f']];
const R_SUN = [[0, '#1a2440', 0], [30, '#3a3a6a', .45], [200, '#8a4f7a', .72], [400, '#d9704a', .84], [600, '#f2a93a', .9], [800, '#f7dc6a', .95], [1000, '#fff4c2', 1]];
const R_Z = [[0, '#35519c'], [.25, '#3f9fc9'], [.5, '#8fcf7a'], [.75, '#f0b43c'], [1, '#d33b4a']];
const R_Q = [[0, '#a8743b'], [.3, '#d8c47a'], [.55, '#7cc48a'], [.8, '#2f9fb0'], [1, '#2a3f9f']];
const R_W = [[-1.2, '#1f4fb0'], [-0.5, '#3fa0d0'], [-0.12, '#bfe3e8', .7], [0, '#eeeeee', .1], [0.08, '#e8d4b0', .6], [0.3, '#b07a3a', .9]];
const R_STRIKE = [[5, '#f2c84b', .3], [20, '#f0a33a', .5], [40, '#e8703a', .65], [60, '#d33b3b', .78], [85, '#9b1f4f', .88]];
const cloudRamp = () => [[0.08, THEME.cloud, 0], [0.35, THEME.cloud, 0.35], [0.7, THEME.cloud, 0.68], [1, THEME.cloud, 0.9]];

const L_ = {
  rain: { g: 'Rain', name: 'Rain intensity', unit: 'mm/h', ramp: () => R_RAIN, min: 0, max: 90, sc: 'sqrt', cut: true, op: 1, dp: 1,
    exact: true, ticks: [0.1, 1, 2.5, 7.6, 20, 50], classes: [[0.1, 2.5, 'Light'], [2.5, 7.6, 'Moderate'], [7.6, 50, 'Heavy'], [50, 90, 'Violent']],
    src: s => ({ model: 'total_precipitation_1hr', imerg: 'imerg_tp_1hr', exp: 'experimental_tp_1hr' })[s.prod] + ' × 1000' },
  accum: { g: 'Rain', name: 'Rain accumulation', unit: 'mm', ramp: () => R_ACC, min: 0, max: 350, sc: 'sqrt', cut: true, op: 1, dp: 0,
    exact: true, ticks: [2.5, 15.6, 64.5, 115.6, 204.5], classes: [[2.5, 15.6, 'Light'], [15.6, 64.5, 'Moderate'], [64.5, 115.6, 'Heavy'], [115.6, 204.5, 'Very heavy'], [204.5, 350, 'Extreme']],
    src: () => 'Sum of total_precipitation_1hr steps' },
  chance: { g: 'Rain', name: 'Chance of rain', unit: '%', ramp: () => R_PCT, min: 0, max: 100, cut: true, op: 1, dp: 0, ticks: [10, 30, 50, 70, 90], grid: 'C',
    src: () => 'Share of ensemble members above the threshold' },
  wind10: { g: 'Wind', name: 'Wind at 10 m', unit: 'm/s', ramp: () => R_WIND, min: 0, max: 55, op: .85, dp: 1, ticks: [0, 5, 10, 17, 25, 33, 45], wind: '10', kmh: true,
    src: () => 'wind_speed_10m, u/v_component_of_wind_10m' },
  wind100: { g: 'Wind', name: 'Wind at 100 m', unit: 'm/s', ramp: () => R_WIND, min: 0, max: 55, op: .85, dp: 1, ticks: [0, 5, 10, 17, 25, 33, 45], wind: '100', kmh: true,
    src: () => 'wind_speed_100m, u/v_component_of_wind_100m' },
  t2: { g: 'Temperature & humidity', name: 'Temperature', unit: '°C', ramp: () => R_TEMP, min: -25, max: 45, op: .85, dp: 1, ticks: [-20, -10, 0, 10, 20, 30, 40], res: true,
    src: s => (s.res === 'station' ? 'station_head_temperature_2m' : 'temperature_2m') + ' − 273.15' },
  td2: { g: 'Temperature & humidity', name: 'Dew point', unit: '°C', ramp: () => R_DEW, min: -20, max: 30, op: .85, dp: 1, ticks: [-15, 0, 10, 20, 26], res: true,
    src: s => (s.res === 'station' ? 'station_head_dewpoint_temperature_2m' : 'dewpoint_temperature_2m') + ' − 273.15' },
  rh: { g: 'Temperature & humidity', name: 'Relative humidity', unit: '%', ramp: () => R_RH, min: 10, max: 100, op: .85, dp: 0, ticks: [20, 40, 60, 80, 100],
    src: () => 'Derived from temperature_2m and dewpoint_temperature_2m' },
  feels: { g: 'Temperature & humidity', name: 'Feels like', unit: '°C', ramp: () => R_TEMP, min: -25, max: 50, op: .85, dp: 1, ticks: [-20, 0, 20, 30, 40, 50],
    src: () => 'Heat index / wind chill from temperature, dew point and wind' },
  tcc: { g: 'Clouds', name: 'Total cloud', unit: '%', ramp: cloudRamp, min: 0, max: 1, op: 1, dp: 0, pct: true, ticks: [0, .25, .5, .75, 1], src: () => 'total_cloud_cover' },
  lcc: { g: 'Clouds', name: 'Low cloud', unit: '%', ramp: cloudRamp, min: 0, max: 1, op: 1, dp: 0, pct: true, ticks: [0, .25, .5, .75, 1], src: () => 'low_cloud_cover' },
  mcc: { g: 'Clouds', name: 'Medium cloud', unit: '%', ramp: cloudRamp, min: 0, max: 1, op: 1, dp: 0, pct: true, ticks: [0, .25, .5, .75, 1], src: () => 'medium_cloud_cover' },
  hcc: { g: 'Clouds', name: 'High cloud', unit: '%', ramp: cloudRamp, min: 0, max: 1, op: 1, dp: 0, pct: true, ticks: [0, .25, .5, .75, 1], src: () => 'high_cloud_cover' },
  mslp: { g: 'Pressure & sea', name: 'Sea-level pressure', unit: 'hPa', ramp: () => R_P, min: 960, max: 1020, op: .8, dp: 0, ticks: [965, 980, 995, 1005, 1015], src: () => 'mean_sea_level_pressure ÷ 100' },
  sst: { g: 'Pressure & sea', name: 'Sea surface temperature', unit: '°C', ramp: () => R_SST, min: 24, max: 32, op: .9, dp: 1, ticks: [25, 27, 28.5, 30, 31.5], ocean: true, src: () => 'sea_surface_temperature − 273.15' },
  ghi: { g: 'Sunshine', name: 'Solar radiation', unit: 'W/m²', ramp: () => R_SUN, min: 0, max: 1000, op: .9, dp: 0, ticks: [0, 200, 400, 600, 800, 1000], src: () => 'surface_solar_radiation_downwards_1hr ÷ 3600' },
  dir: { g: 'Sunshine', name: 'Direct sunlight', unit: 'W/m²', ramp: () => R_SUN, min: 0, max: 1000, op: .9, dp: 0, ticks: [0, 200, 400, 600, 800, 1000], src: () => 'total_sky_direct_solar_radiation_at_surface_1hr ÷ 3600' },
  uwind: { g: 'Upper air', name: 'Wind', unit: 'm/s', ramp: () => R_WIND, min: 0, max: 60, op: .85, dp: 1, ticks: [0, 10, 20, 30, 45, 60], wind: 'up', lev: true, kmh: true, src: s => `u/v_component_of_wind_${s.lev}` },
  utemp: { g: 'Upper air', name: 'Temperature', unit: '°C', ramp: () => R_UTEMP, min: -80, max: 30, op: .85, dp: 1, ticks: [-75, -50, -25, 0, 25], lev: true, src: s => `temperature_${s.lev} − 273.15` },
  uz: { g: 'Upper air', name: 'Geopotential height', unit: 'm', ramp: () => R_Z, auto: true, op: .85, dp: 0, lev: true, src: s => `geopotential_${s.lev} ÷ 9.80665` },
  uq: { g: 'Upper air', name: 'Specific humidity', unit: 'g/kg', ramp: () => R_Q, auto: true, op: .85, dp: 2, lev: true, src: s => `specific_humidity_${s.lev} × 1000` },
  uw: { g: 'Upper air', name: 'Vertical motion', unit: 'Pa/s', ramp: () => R_W, min: -1.2, max: 0.3, op: .9, dp: 2, ticks: [-1, -0.5, 0, 0.3], lev: true, src: s => `vertical_velocity_${s.lev} (negative = rising air)` },
  strike: { g: 'Cyclone', name: 'Cyclone strike chance', unit: '%', ramp: () => R_STRIKE, min: 0, max: 100, cut: true, op: 1, dp: 0, ticks: [10, 30, 50, 70, 90], grid: 'C',
    src: () => 'Share of ensemble tracks passing within 110 km during the forecast' }
};
/* ================= colour ================= */
const hex = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
function rampColor(stops, v) {
  if (v <= stops[0][0]) { const c = hex(stops[0][1]); return [...c, stops[0][2] ?? 1]; }
  for (let i = 1; i < stops.length; i++) if (v <= stops[i][0]) {
    const a = stops[i - 1], b = stops[i], f = (v - a[0]) / (b[0] - a[0]), ca = hex(a[1]), cb = hex(b[1]);
    return [ca[0] + (cb[0] - ca[0]) * f, ca[1] + (cb[1] - ca[1]) * f, ca[2] + (cb[2] - ca[2]) * f, (a[2] ?? 1) + ((b[2] ?? 1) - (a[2] ?? 1)) * f];
  }
  const l = stops[stops.length - 1]; return [...hex(l[1]), l[2] ?? 1];
}
const tf = (l, v) => l.sc === 'sqrt' ? Math.sqrt(Math.max(0, v)) : v;
const itf = (l, v) => l.sc === 'sqrt' ? v * v : v;
let LUT = null, LUTfor = '';
function buildLUT(l, mn, mx) {
  const lut = new Uint8ClampedArray(256 * 4), t0 = tf(l, mn), t1 = tf(l, mx), stops = l.ramp();
  const norm = l.auto; // ramp in 0..1
  for (let k = 0; k < 256; k++) {
    const v = itf(l, t0 + (t1 - t0) * k / 255);
    const c = rampColor(stops, norm ? k / 255 : v);
    lut[k * 4] = c[0]; lut[k * 4 + 1] = c[1]; lut[k * 4 + 2] = c[2]; lut[k * 4 + 3] = c[3] * 255;
  }
  return lut;
}
/* ================= contours (isobars) ================= */
function contours(a, g, step) {
  const segs = []; let mn = 1e9, mx = -1e9; for (const v of a) { if (v < mn) mn = v; if (v > mx) mx = v; }
  const nx = g.nx, P = (x, y) => [g.lon0 + x * g.d, g.lat1 - y * g.d];
  for (let lv = Math.ceil(mn / step) * step; lv <= mx; lv += step) {
    const seg = [];
    for (let j = 0; j < g.ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
      const v0 = a[j * nx + i], v1 = a[j * nx + i + 1], v2 = a[(j + 1) * nx + i + 1], v3 = a[(j + 1) * nx + i];
      const c = (v0 > lv ? 1 : 0) | (v1 > lv ? 2 : 0) | (v2 > lv ? 4 : 0) | (v3 > lv ? 8 : 0);
      if (c === 0 || c === 15) continue;
      const e = [];
      if ((v0 > lv) !== (v1 > lv)) e.push(P(i + (lv - v0) / (v1 - v0), j));
      if ((v1 > lv) !== (v2 > lv)) e.push(P(i + 1, j + (lv - v1) / (v2 - v1)));
      if ((v3 > lv) !== (v2 > lv)) e.push(P(i + (lv - v3) / (v2 - v3), j + 1));
      if ((v0 > lv) !== (v3 > lv)) e.push(P(i, j + (lv - v0) / (v3 - v0)));
      if (e.length === 2) seg.push(e[0], e[1]); else if (e.length === 4) seg.push(e[0], e[1], e[2], e[3]);
    }
    segs.push({ lv, seg });
  }
  return segs;
}

/* ================= time helpers ================= */
let INIT = Date.UTC(2026, 8, 24, 0, 0, 0);
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ist = t => new Date(INIT + (t + 5.5) * 3600e3);
const pad = n => String(n).padStart(2, '0');
const fmtTime = t => { const d = ist(t); return `${DAYS[d.getUTCDay()]} ${d.getUTCDate()} ${MON[d.getUTCMonth()]}, ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())} IST`; };
const fmtShort = t => { const d = ist(t); return `${DAYS[d.getUTCDay()]} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; };
const COMPASS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
const compass = deg => COMPASS[Math.round(((deg % 360) + 360) % 360 / 22.5) % 16];
function imdCat(ms) {
  const kt = ms * 1.944;
  if (kt < 17) return ['Low-pressure area', 0]; if (kt < 28) return ['Depression', 1]; if (kt < 34) return ['Deep depression', 2];
  if (kt < 48) return ['Cyclonic storm', 3]; if (kt < 64) return ['Severe cyclonic storm', 4]; if (kt < 90) return ['Very severe cyclonic storm', 5];
  if (kt < 120) return ['Extremely severe cyclonic storm', 6]; return ['Super cyclonic storm', 7];
}
const CATCOL = ['#8aa1ab', '#7fc4e8', '#56c48a', '#e9d24b', '#f0a33a', '#e8603a', '#c42a7b', '#8a42d6'];

/* ================= places ================= */
const CITIES = [
  ['Guntur', 16.31, 80.44, 2], ['Vijayawada', 16.51, 80.65, 2], ['Visakhapatnam', 17.69, 83.22, 1], ['Machilipatnam', 16.19, 81.14, 3], ['Kakinada', 16.99, 82.25, 3],
  ['Nellore', 14.44, 79.99, 3], ['Ongole', 15.50, 80.05, 3], ['Tirupati', 13.63, 79.42, 3], ['Kurnool', 15.83, 78.04, 3], ['Nandyal', 15.48, 78.48, 3],
  ['Anantapur', 14.68, 77.60, 3], ['Srikakulam', 18.30, 83.90, 3], ['Rajahmundry', 17.00, 81.80, 3], ['Eluru', 16.71, 81.10, 3], ['Kadapa', 14.47, 78.82, 3],
  ['Hyderabad', 17.39, 78.49, 1], ['Chennai', 13.08, 80.27, 1], ['Bengaluru', 12.97, 77.59, 1], ['Bhubaneswar', 20.30, 85.82, 2], ['Kolkata', 22.57, 88.36, 1],
  ['Mumbai', 19.08, 72.88, 1], ['Delhi', 28.61, 77.21, 1], ['Thiruvananthapuram', 8.52, 76.94, 2], ['Puducherry', 11.94, 79.81, 3], ['Nagpur', 21.15, 79.09, 2],
  ['Raipur', 21.25, 81.63, 2], ['Ahmedabad', 23.02, 72.57, 2], ['Jaipur', 26.91, 75.79, 2], ['Lucknow', 26.85, 80.95, 2], ['Patna', 25.59, 85.14, 2],
  ['Guwahati', 26.14, 91.74, 2], ['Dhaka', 23.81, 90.41, 1], ['Colombo', 6.93, 79.86, 1], ['Yangon', 16.84, 96.17, 1], ['Kathmandu', 27.72, 85.32, 2],
  ['Karachi', 24.86, 67.01, 1], ['Port Blair', 11.62, 92.73, 2], ['Warangal', 17.97, 79.59, 3], ['Kochi', 9.93, 76.27, 2], ['Madurai', 9.93, 78.12, 3]
];
function nearestCity(lon, lat, maxd) {
  let best = null, bd = maxd * maxd;
  for (const c of CITIES) { const dx = (c[2] - lon) * Math.cos(lat * D2R), dy = c[1] - lat, d = dx * dx + dy * dy; if (d < bd) { bd = d; best = c; } }
  return best;
}
/* ================= theme ================= */
const THEME = {};
function readTheme() {
  const cs = getComputedStyle(document.documentElement), g = n => cs.getPropertyValue(n).trim();
  Object.assign(THEME, { ocean: g('--ocean'), land: g('--land'), coast: g('--coast'), border: g('--border'), ink: g('--ink'), muted: g('--muted'), accent: g('--accent'), storm: g('--storm'), particle: g('--particle'), cloud: g('--cloud'), halo: g('--halo') });
}
