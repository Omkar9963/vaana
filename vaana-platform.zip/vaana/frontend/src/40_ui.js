/* ================= configuration ================= */
const CFG = Object.assign({ dataUrl: '' }, window.VAANA_CONFIG || {});
const QP = new URLSearchParams(location.search);
if (QP.has('data')) CFG.dataUrl = QP.get('data');
if (QP.has('demo')) CFG.dataUrl = '';
let SRC = null;

const state = { layer: 'rain', si: 0, t: 0, prod: 'model', per: 24, thr: 64.5, res: 'grid', lev: 850, flow: true, isob: false, cyc: true, sel: null };
const GROUPS = [];
for (const [id, l] of Object.entries(L_)) l.id = id;

function layerAvailable(id) {
  if (!SRC.live) return true;
  const Ls = SRC.meta.layers, l = L_[id];
  if (l.lev) return SRC.levelsFor(id).length > 0;
  const need = { wind10: 'ws10', wind100: 'ws100', rain: 'rain_' + SRC.rainProducts[0], accum: 'accum' + SRC.accum[0],
    chance: 'chance_' + thrCode(SRC.chance[0]), rh: 'td2', feels: 'td2', strike: null }[id];
  return need === null ? true : !!Ls[need === undefined ? id : need];
}

/* ================= DOM & view ================= */
const $ = s => document.querySelector(s);
const mapEl = $('#map'), base = $('#base'), parts = $('#parts'), bctx = base.getContext('2d'), pctx = parts.getContext('2d');
let W = 0, H = 0, dpr = 1, dirty = true;
const view = { cx: 82, cy: 17.5, ppd: 20 }, KX = 0.95;
const X = lon => (lon - view.cx) * view.ppd * KX + W / 2, Y = lat => (view.cy - lat) * view.ppd + H / 2;
const LON = x => (x - W / 2) / (view.ppd * KX) + view.cx, LAT = y => view.cy - (y - H / 2) / view.ppd;
function resize() {
  const r = mapEl.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio || 1);
  const first = W === 0; W = r.width; H = r.height;
  for (const c of [base, parts]) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
  if (first) fitView();
  resetParticles(); dirty = true;
}
function fitView() {
  const narrow = W < 760;
  view.ppd = clamp(Math.min(W / ((narrow ? 22 : 34) * KX), H / (narrow ? 26 : 27)), 8, 400);
  view.cx = narrow ? 82 : 83.5; view.cy = narrow ? 16.5 : 17.5;
}

/* ================= rendering ================= */
let FIELD = null, WIND = null, ISO = [];
function renderField(l, F) {
  const g = F.g, a = F.a;
  let mn = l.min, mx = l.max;
  if (l.auto) {
    let lo = 1e9, hi = -1e9; for (let k = 0; k < a.length; k += 7) { const v = a[k]; if (v < lo) lo = v; if (v > hi) hi = v; }
    const step = l.id === 'uz' ? 10 : 0.5; mn = Math.floor(lo / step) * step; mx = Math.ceil(hi / step) * step; if (!(mx - mn > 1e-6)) mx = mn + step;
  }
  const key = l.id + mn + mx + THEME.cloud;
  if (key !== LUTfor) { LUT = buildLUT(l, mn, mx); LUTfor = key; }
  const c = (FIELD && FIELD.img.width === g.nx && FIELD.img.height === g.ny) ? FIELD.img : document.createElement('canvas');
  c.width = g.nx; c.height = g.ny;
  const x = c.getContext('2d'), im = x.createImageData(g.nx, g.ny), d = im.data, t0 = tf(l, mn), t1 = tf(l, mx);
  const cut = l.id === 'rain' ? 0.1 : l.id === 'accum' ? 1 : 5;
  for (let k = 0; k < a.length; k++) {
    const v = a[k];
    if (isNaN(v) || (l.cut && v < cut)) { d[k * 4 + 3] = 0; continue; }
    const q = clamp(Math.round((tf(l, v) - t0) / (t1 - t0) * 255), 0, 255) * 4;
    d[k * 4] = LUT[q]; d[k * 4 + 1] = LUT[q + 1]; d[k * 4 + 2] = LUT[q + 2]; d[k * 4 + 3] = LUT[q + 3];
  }
  x.putImageData(im, 0, 0);
  FIELD = { img: c, g, a, mn, mx };
  updateLegend(l, mn, mx, F.h);
}
function drawBase() {
  const c = bctx; c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.fillStyle = THEME.ocean; c.fillRect(0, 0, W, H);
  const land = new Path2D();
  for (const r of LANDR) { r.forEach((p, k) => k ? land.lineTo(X(p[0]), Y(p[1])) : land.moveTo(X(p[0]), Y(p[1]))); land.closePath(); }
  c.fillStyle = THEME.land; c.fill(land, 'evenodd');
  if (FIELD) {
    const g = FIELD.g, l = L_[state.layer];
    c.save(); c.globalAlpha = l.op; c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high';
    c.drawImage(FIELD.img, X(g.lon0 - g.d / 2), Y(g.lat1 + g.d / 2), g.nx * g.d * view.ppd * KX, g.ny * g.d * view.ppd);
    c.restore();
  }
  c.lineJoin = 'round';
  c.strokeStyle = THEME.coast; c.lineWidth = 0.9; c.stroke(land);
  c.beginPath(); for (const r of BORDR) r.forEach((p, k) => k ? c.lineTo(X(p[0]), Y(p[1])) : c.moveTo(X(p[0]), Y(p[1])));
  c.strokeStyle = THEME.border; c.lineWidth = 0.7; c.setLineDash([3, 3]); c.stroke(); c.setLineDash([]);
  c.strokeStyle = THEME.border; c.lineWidth = 1; c.strokeRect(X(55), Y(38), 50 * view.ppd * KX, 43 * view.ppd);
  if (state.isob) drawIsobars(c);
  if (state.cyc && SRC && SRC.storms) drawCyclones(c);
  drawCities(c);
  if (state.sel) { const x = X(state.sel[0]), y = Y(state.sel[1]); c.beginPath(); c.arc(x, y, 7, 0, 2 * PI); c.lineWidth = 3; c.strokeStyle = THEME.halo; c.stroke(); c.lineWidth = 1.6; c.strokeStyle = THEME.accent; c.stroke(); c.beginPath(); c.arc(x, y, 2, 0, 2 * PI); c.fillStyle = THEME.accent; c.fill(); }
}
function drawIsobars(c) {
  c.strokeStyle = THEME.ink; c.globalAlpha = 0.55; c.lineWidth = 0.9;
  const labels = []; c.font = '600 10px "Instrument Sans", system-ui, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
  for (const L of ISO) {
    c.beginPath(); const s = L.seg; for (let k = 0; k < s.length; k += 2) { c.moveTo(X(s[k][0]), Y(s[k][1])); c.lineTo(X(s[k + 1][0]), Y(s[k + 1][1])); } c.stroke();
    if (L.lv % 4 === 0) for (let k = 0; k < s.length; k += 38) {
      const x = X(s[k][0]), y = Y(s[k][1]); if (x < 30 || y < 30 || x > W - 30 || y > H - 30) continue;
      if (labels.some(p => Math.abs(p[0] - x) < 90 && Math.abs(p[1] - y) < 40)) continue; labels.push([x, y, L.lv]);
    }
  }
  c.globalAlpha = 1;
  for (const [x, y, v] of labels) { c.fillStyle = THEME.halo; c.fillRect(x - 15, y - 7, 30, 14); c.fillStyle = THEME.ink; c.fillText(v, x, y); }
}

/* ================= cyclones ================= */
function stormAt(s, h) {
  const m = s.median; if (!m.length || h < m[0][0] || h > m[m.length - 1][0]) return null;
  let k = 0; while (k < m.length - 2 && m[k + 1][0] < h) k++;
  const a = m[k], b = m[Math.min(k + 1, m.length - 1)], span = (b[0] - a[0]) || 1, f = clamp((h - a[0]) / span, 0, 1);
  return { x: a[1] + (b[1] - a[1]) * f, y: a[2] + (b[2] - a[2]) * f, p: a[3] + (b[3] - a[3]) * f, v: a[4] + (b[4] - a[4]) * f, mx: (b[1] - a[1]) / span, my: (b[2] - a[2]) / span };
}
function activeStorm(h) {
  let best = null;
  for (const s of SRC.storms) { const st = stormAt(s, h); if (st && st.v >= 8.7 && (!best || st.v > best.st.v)) best = { s, st }; }
  return best;
}
function landfall(s) {
  if (s._lf !== undefined) return s._lf;
  const first = tr => { for (let k = 1; k < tr.length; k++) if (landAt(tr[k][1], tr[k][2]) > 0.5 && landAt(tr[k - 1][1], tr[k - 1][2]) <= 0.5) return tr[k]; return null; };
  const m = first(s.median); if (!m) return (s._lf = null);
  const hs = s.tracks.map(first).filter(Boolean).map(p => p[0]).sort((a, b) => a - b);
  return (s._lf = { h: m[0], x: m[1], y: m[2], city: nearestCity(m[1], m[2], 1.5), lo: hs.length ? hs[Math.floor(hs.length * 0.1)] : m[0], hi: hs.length ? hs[Math.min(hs.length - 1, Math.floor(hs.length * 0.9))] : m[0] });
}
function drawCyclones(c) {
  for (const s of SRC.storms) {
    c.lineWidth = 1; c.strokeStyle = THEME.storm; c.globalAlpha = 0.32;
    for (const tr of s.tracks) { c.beginPath(); tr.forEach((p, k) => k ? c.lineTo(X(p[1]), Y(p[2])) : c.moveTo(X(p[1]), Y(p[2]))); c.stroke(); }
    c.globalAlpha = 1;
    const m = s.median;
    c.lineWidth = 3.5; c.strokeStyle = THEME.halo; c.beginPath(); m.forEach((p, k) => k ? c.lineTo(X(p[1]), Y(p[2])) : c.moveTo(X(p[1]), Y(p[2]))); c.stroke();
    c.lineWidth = 2; c.strokeStyle = THEME.storm; c.stroke();
    c.font = '600 11px "Instrument Sans", system-ui, sans-serif'; c.textBaseline = 'middle'; c.textAlign = 'left';
    for (const p of m) {
      if (p[0] % 12) continue;
      const x = X(p[1]), y = Y(p[2]), cat = imdCat(p[4])[1];
      c.beginPath(); c.arc(x, y, p[0] % 24 === 0 ? 5 : 3.5, 0, 2 * PI); c.fillStyle = CATCOL[cat]; c.fill(); c.lineWidth = 1.2; c.strokeStyle = THEME.halo; c.stroke();
      if (p[0] % 24 === 0 && view.ppd > 12) { const t = fmtShort(p[0]); c.lineWidth = 3; c.strokeStyle = THEME.halo; c.strokeText(t, x + 9, y - 9); c.fillStyle = THEME.ink; c.fillText(t, x + 9, y - 9); }
    }
    const st = stormAt(s, state.t);
    if (st && st.v >= 8.7) {
      const x = X(st.x), y = Y(st.y), R = 11;
      c.save(); c.translate(x, y); c.lineWidth = 2.6; c.strokeStyle = THEME.halo;
      const glyph = () => { c.beginPath(); c.arc(0, 0, R * 0.45, 0, 2 * PI); c.moveTo(R * 0.45, 0); c.arc(R * 1.1, 0, R * 0.65, PI, PI * 1.6, false); c.moveTo(-R * 0.45, 0); c.arc(-R * 1.1, 0, R * 0.65, 0, PI * 0.6, false); };
      glyph(); c.stroke(); c.lineWidth = 1.8; c.strokeStyle = CATCOL[imdCat(st.v)[1]]; glyph(); c.stroke(); c.restore();
    }
  }
}
function updateStorm() {
  const box = $('#storm'); box.hidden = !state.cyc; if (!state.cyc) return;
  const tag = SRC.live ? '' : ' (sample)';
  if (!SRC.storms.length) { $('#st-title').textContent = 'Cyclones'; $('#st-body').hidden = true; $('#st-none').hidden = false; $('#st-none').textContent = 'No tropical cyclone in this forecast.'; return; }
  const act = activeStorm(state.t), s = act ? act.s : SRC.storms[0];
  $('#st-title').textContent = `Cyclone in the ${s.basin}${tag}`;
  $('#st-body').hidden = false; $('#st-none').hidden = true;
  const st = act ? act.st : null;
  if (st) {
    const [cat, ci] = imdCat(st.v), cl = Math.cos(st.y * D2R);
    $('#st-cat').textContent = cat; $('#st-cat').style.setProperty('--cat', CATCOL[ci]);
    $('#st-wind').textContent = `${Math.round(st.v * 3.6)} km/h (${Math.round(st.v * 1.944)} kt)`;
    $('#st-p').textContent = `${Math.round(st.p)} hPa`;
    $('#st-move').textContent = `${compass(Math.atan2(st.mx * cl, st.my) / D2R)} at ${Math.round(Math.hypot(st.mx * cl, st.my) * 111)} km/h`;
  } else {
    const first = s.median[0][0];
    $('#st-cat').textContent = state.t < first ? `Forms around ${fmtShort(first)} IST` : 'Weakened'; $('#st-cat').style.setProperty('--cat', CATCOL[0]);
    $('#st-wind').textContent = $('#st-p').textContent = $('#st-move').textContent = '—';
  }
  const lf = landfall(s);
  if (lf) {
    const where = lf.city ? `near ${lf.city[0]}` : 'on the coast';
    $('#st-land').textContent = state.t >= lf.h ? `Crossed the coast ${where}, ${fmtTime(lf.h)}` : `Expected to cross the coast ${where}, around ${fmtTime(lf.h)}`;
    $('#st-range').textContent = `Ensemble timing range: ${fmtShort(lf.lo)} to ${fmtShort(lf.hi)} IST`;
  } else { $('#st-land').textContent = 'Stays over the sea in this forecast'; $('#st-range').textContent = ''; }
  $('#st-note').textContent = `Tracks from ${s.tracks.length} of ${SRC.members} ensemble members. ${SRC.storms.length > 1 ? `${SRC.storms.length} systems in this forecast. ` : ''}Official cyclone warnings come from IMD.`;
}

/* ================= cities ================= */
function drawCities(c) {
  c.font = '500 11px "Instrument Sans", system-ui, sans-serif'; c.textBaseline = 'middle'; c.textAlign = 'left';
  const tier = view.ppd >= 55 ? 3 : view.ppd >= 26 ? 2 : 1;
  for (const [n, lat, lon, t] of CITIES) {
    if (t > tier) continue; const x = X(lon), y = Y(lat); if (x < -40 || y < -20 || x > W + 40 || y > H + 20) continue;
    c.beginPath(); c.arc(x, y, 2.4, 0, 2 * PI); c.fillStyle = THEME.ink; c.fill();
    c.lineWidth = 3; c.strokeStyle = THEME.halo; c.strokeText(n, x + 6, y); c.fillStyle = THEME.ink; c.fillText(n, x + 6, y);
  }
}

/* ================= particles ================= */
let PT = [];
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
function resetParticles() {
  const n = Math.round(clamp(W * H / 300, 800, 5000)); PT = [];
  for (let i = 0; i < n; i++) PT.push(spawn({}));
  pctx.setTransform(1, 0, 0, 1, 0, 0); pctx.clearRect(0, 0, parts.width, parts.height);
}
function spawn(p) { p.lon = LON(Math.random() * W); p.lat = LAT(Math.random() * H); p.age = Math.floor(Math.random() * 80); p.max = 50 + Math.random() * 60; return p; }
function stepParticles() {
  const c = pctx; c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.globalCompositeOperation = 'destination-in'; c.fillStyle = 'rgba(0,0,0,0.9)'; c.fillRect(0, 0, W, H); c.globalCompositeOperation = 'source-over';
  if (!state.flow || !WIND) return;
  const k = WIND.up ? 0.16 : 0.3;
  c.lineWidth = 1.1; c.strokeStyle = `rgba(${THEME.particle},0.8)`; c.beginPath();
  for (const p of PT) {
    const u = sample(WIND.u, WIND.g, p.lon, p.lat), v = sample(WIND.v, WIND.g, p.lon, p.lat);
    if (isNaN(u) || isNaN(v) || p.age++ > p.max) { spawn(p); p.age = 0; continue; }
    const x0 = X(p.lon), y0 = Y(p.lat);
    p.lon += u * k / (view.ppd * KX); p.lat += v * k / view.ppd;
    c.moveTo(x0, y0); c.lineTo(X(p.lon), Y(p.lat));
  }
  c.stroke();
}

/* ================= controls ================= */
const rail = $('#rail');
function buildRail() {
  GROUPS.length = 0;
  for (const [id, l] of Object.entries(L_)) {
    if (!layerAvailable(id)) continue;
    let g = GROUPS.find(x => x.name === l.g); if (!g) GROUPS.push(g = { name: l.g, ids: [] }); g.ids.push(id);
  }
  rail.innerHTML = '';
  for (const g of GROUPS) {
    const sec = document.createElement('div'); sec.className = 'grp';
    const h = document.createElement('div'); h.className = 'grp-name'; h.textContent = g.name; sec.appendChild(h);
    for (const id of g.ids) {
      const b = document.createElement('button'); b.className = 'lay'; b.dataset.id = id; b.textContent = L_[id].name;
      b.setAttribute('aria-pressed', id === state.layer); b.onclick = () => setLayer(id); sec.appendChild(b);
    }
    rail.appendChild(sec);
  }
}
function setLayer(id) {
  state.layer = id; rail.querySelectorAll('.lay').forEach(b => b.setAttribute('aria-pressed', b.dataset.id === id));
  const btn = rail.querySelector(`[data-id="${id}"]`); if (btn && btn.scrollIntoView) btn.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  buildOpts(); refresh();
}
function seg(label, opts, cur, on) {
  const w = document.createElement('div'); w.className = 'opt';
  const h = document.createElement('div'); h.className = 'opt-name'; h.textContent = label; w.appendChild(h);
  const s = document.createElement('div'); s.className = 'seg'; s.setAttribute('role', 'group'); s.setAttribute('aria-label', label);
  for (const [v, t] of opts) { const b = document.createElement('button'); b.textContent = t; b.setAttribute('aria-pressed', v === cur); b.onclick = () => { on(v); buildOpts(); refresh(); }; s.appendChild(b); }
  w.appendChild(s); return w;
}
const PROD = { model: 'Model', imerg: 'IMERG-calibrated', exp: 'Satellite-radar' };
const THR = { 2.5: '2.5 mm', 64.5: '64.5 mm heavy', 115.6: '115.6 mm very heavy' };
function buildOpts() {
  const box = $('#layer-opts'), l = L_[state.layer]; box.innerHTML = '';
  if (l.id === 'rain' && SRC.rainProducts.length > 1) box.appendChild(seg('Rain product', SRC.rainProducts.map(p => [p, PROD[p] || p]), state.prod, v => state.prod = v));
  if (l.id === 'accum') box.appendChild(seg('Total over the next', SRC.accum.map(n => [n, n === 72 ? '3 days' : `${n} hours`]), state.per, v => state.per = v));
  if (l.id === 'chance') box.appendChild(seg('Rain in the next 24 hours of at least', SRC.chance.map(t => [t, THR[t] || `${t} mm`]), state.thr, v => state.thr = v));
  if (l.res && SRC.hasStation) box.appendChild(seg('Detail', [['grid', '10 km grid'], ['station', '5 km station-trained']], state.res, v => state.res = v));
  if (l.lev) {
    const lv = SRC.levelsFor(l.id);
    if (!lv.includes(state.lev)) state.lev = lv.includes(850) ? 850 : lv[0];
    const w = seg('Pressure level (hPa)', lv.map(p => [p, String(p)]), state.lev, v => state.lev = v);
    const hint = document.createElement('div'); hint.className = 'opt-hint'; hint.textContent = '850 ≈ 1.5 km, 500 ≈ 5.8 km, 200 ≈ 12 km above sea level';
    w.appendChild(hint); w.querySelector('.seg').classList.add('levels'); box.appendChild(w);
  }
  if (!box.children.length) { const p = document.createElement('div'); p.className = 'opt-hint'; p.textContent = 'No extra settings for this layer.'; box.appendChild(p); }
}
function buildToggles() {
  const box = $('#toggles'); box.innerHTML = '';
  for (const [k, t] of [['flow', 'Wind flow'], ['isob', 'Isobars'], ['cyc', 'Cyclone tracks']]) {
    const b = document.createElement('button'); b.className = 'tog'; b.textContent = t; b.setAttribute('aria-pressed', state[k]);
    b.onclick = () => { state[k] = !state[k]; b.setAttribute('aria-pressed', state[k]); if (k === 'flow') resetParticles(); refresh(); };
    box.appendChild(b);
  }
}

/* ================= legend ================= */
function fmtVal(l, v) { if (l.pct) return Math.round(v * 100); return (Math.abs(v) >= 100 || l.dp === 0) ? Math.round(v) : v.toFixed(l.dp === 2 ? 2 : 1).replace(/\.0$/, ''); }
function updateLegend(l, mn, mx, shownH) {
  const t0 = tf(l, mn), t1 = tf(l, mx), stops = [], lut = LUT;
  for (let i = 0; i <= 24; i++) { const q = Math.round(i / 24 * 255) * 4; stops.push(`rgba(${lut[q]},${lut[q + 1]},${lut[q + 2]},${Math.max(0.25, lut[q + 3] / 255).toFixed(2)}) ${(i / 24 * 100).toFixed(1)}%`); }
  $('#lg-bar').style.background = `linear-gradient(90deg, ${stops.join(',')})`;
  const pos = v => clamp((tf(l, v) - t0) / (t1 - t0) * 100, 0, 100);
  let ticks = l.ticks; if (l.auto) { ticks = []; for (let i = 0; i <= 4; i++) ticks.push(mn + (mx - mn) * i / 4); }
  $('#lg-ticks').innerHTML = ticks.map(v => `<span style="left:${pos(v)}%">${l.exact ? v : fmtVal(l, v)}</span>`).join('');
  $('#lg-classes').innerHTML = (l.classes || []).map(([a, b, n]) => `<span style="left:${pos(a)}%;width:${pos(b) - pos(a)}%">${n}</span>`).join('');
  $('#lg-classes').hidden = !l.classes;
  let title = l.id === 'rain' && SRC.stepHours > 1 ? `Rain rate, ${SRC.stepHours}-hour average` : l.name; if (l.lev) title += ` at ${state.lev} hPa`; if (l.id === 'accum') title += `, next ${state.per === 72 ? '3 days' : state.per + ' hours'}`;
  if (l.id === 'chance') title += ` ≥ ${state.thr} mm in 24 h`;
  $('#lg-title').textContent = title; $('#lg-unit').textContent = l.unit;
  const fl = SRC.fileLayer(l.id, state);
  let src = (SRC.live && SRC.meta.srcvars && SRC.meta.srcvars[fl]) || l.src(state);
  if (l.lev && shownH !== undefined && shownH !== state.t) src += `. Pressure levels come every 6 h: showing ${fmtShort(shownH)} IST`;
  if (SRC.live && l.id !== 'strike') src += SRC.members > 1 && !['chance', 'strike'].includes(l.id) ? `. Ensemble mean of ${SRC.members} members` : '';
  $('#lg-src').textContent = src;
}
function legendMessage(msg) { $('#lg-msg').textContent = msg || ''; $('#lg-msg').hidden = !msg; }

/* ================= timeline ================= */
const slider = $('#time');
function buildTicks() {
  const n = SRC.steps.length, box = $('#ticks'), pctOf = i => i / (n - 1) * 100; let h = '', lab = '';
  const dayOf = hr => ist(hr).getUTCDate();
  let start = 0;
  for (let i = 1; i <= n; i++) {
    if (i === n || dayOf(SRC.steps[i]) !== dayOf(SRC.steps[i - 1])) {
      if (i < n) h += `<span style="left:${pctOf(i - 0.5)}%"></span>`;
      const d = ist(SRC.steps[start]);
      if ((pctOf(i - 1) - pctOf(start)) > (n > 130 ? 2.5 : 4)) lab += `<em style="left:${(pctOf(start) + pctOf(i - 1)) / 2}%"><i>${DAYS[d.getUTCDay()]} </i>${d.getUTCDate()}</em>`;
      start = i;
    }
  }
  box.innerHTML = h + lab;
  slider.max = n - 1;
}
function setStep(i) { state.si = clamp(Math.round(i), 0, SRC.steps.length - 1); slider.value = state.si; refresh(); }
function setHour(h) { let best = 0; SRC.steps.forEach((s, i) => { if (Math.abs(s - h) < Math.abs(SRC.steps[best] - h)) best = i; }); setStep(best); }
let playing = false, playTimer = 0;
function togglePlay(force) {
  playing = force === undefined ? !playing : force; const b = $('#play'); b.setAttribute('aria-pressed', playing); b.setAttribute('aria-label', playing ? 'Pause' : 'Play');
  b.innerHTML = playing ? '<svg viewBox="0 0 20 20" width="18" height="18"><rect x="5" y="4" width="3.5" height="12" rx="1" fill="currentColor"/><rect x="11.5" y="4" width="3.5" height="12" rx="1" fill="currentColor"/></svg>' : '<svg viewBox="0 0 20 20" width="18" height="18"><path d="M6 4l10 6-10 6z" fill="currentColor"/></svg>';
  clearTimeout(playTimer); if (playing) tick();
}
async function tick() {
  if (!playing) return;
  await refreshTo(state.si >= SRC.steps.length - 1 ? 0 : state.si + 1);
  playTimer = setTimeout(tick, 260);
}
async function refreshTo(i) { state.si = i; slider.value = i; await refresh(); }

/* ================= point forecast ================= */
let SERIES = null;
async function openPoint(lon, lat, name) {
  if (lon < 55 || lon > 105 || lat < -5 || lat > 38) return;
  state.sel = [lon, lat]; dirty = true;
  const c = nearestCity(lon, lat, 0.35);
  $('#pt-name').textContent = name || (c ? c[0] : (landAt(lon, lat) > 0.5 ? 'Selected location' : 'Open sea'));
  $('#pt-coord').textContent = `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? 'N' : 'S'}, ${lon.toFixed(2)}°E`;
  $('#point').hidden = false; document.body.classList.add('pt-open');
  $('#pt-loading').hidden = false; $('#pt-content').hidden = true;
  try {
    const s = await SRC.point(lon, lat); if (!s || state.sel?.[0] !== lon) return;
    SERIES = s; $('#pt-loading').hidden = true; $('#pt-content').hidden = false;
    renderDaily(); updatePointNow(); drawChart();
  } catch (e) { console.warn(e); $('#pt-loading').textContent = 'The forecast for this place could not be loaded. Try another spot or reload the page.'; }
}
function closePoint() { $('#point').hidden = true; document.body.classList.remove('pt-open'); state.sel = null; SERIES = null; dirty = true; }
function rainClass(r) { return r < 0.1 ? 'Dry' : r < 2.5 ? 'Light' : r < 7.6 ? 'Moderate' : r < 50 ? 'Heavy' : 'Violent'; }
const f1 = v => isNaN(v) ? '–' : v.toFixed(1), f0 = v => isNaN(v) ? '–' : Math.round(v);
function updatePointNow() {
  if (!SERIES) return; const o = SERIES.now[state.si]; if (!o) return;
  const rh = rhOf(o.t2, o.td2), ws = Math.hypot(o.u10, o.v10), from = compass(Math.atan2(-o.u10, -o.v10) / D2R);
  $('#pt-when').textContent = fmtTime(state.t);
  $('#pt-now').innerHTML = [
    ['Temperature', `${f1(o.t2)}<small>°C</small>`, `Feels like ${f0(feelsOf(o.t2, rh, ws))}°C`],
    ['Rain', `${f1(o.rain)}<small>mm/h</small>`, rainClass(o.rain)],
    ['Wind', `${f0(ws * 3.6)}<small>km/h</small>`, `From ${from}, ${f0(o.ws100)} km/h at 100 m`],
    ['Humidity', `${f0(rh)}<small>%</small>`, `Dew point ${f1(o.td2)}°C`],
    ['Pressure', `${f0(o.mslp)}<small>hPa</small>`, `Cloud ${f0(o.tcc * 100)}%`],
    ['Sunshine', `${f0(o.ghi)}<small>W/m²</small>`, o.ghi > 0 ? `Direct ${f0(o.dir)} W/m²` : 'Night']
  ].map(([k, v, s]) => `<div class="now-item"><div class="now-k">${k}</div><div class="now-v">${v}</div><div class="now-s">${s}</div></div>`).join('');
}
function renderDaily() {
  $('#pt-daily').innerHTML = `<table><thead><tr><th scope="col">Day</th><th scope="col">Min / max</th><th scope="col">Rain</th><th scope="col">Chance</th><th scope="col">Max wind</th></tr></thead><tbody>${SERIES.daily.map(d => `<tr><th scope="row">${d.day}${d.partial ? '<sup title="Partial day">*</sup>' : ''}</th><td>${f0(d.tn)}° / ${f0(d.tx)}°</td><td>${d.rain < 0.5 ? '0' : d.rain.toFixed(d.rain < 10 ? 1 : 0)} mm</td><td><span class="bar" style="--p:${d.chance}%"></span>${d.chance}%</td><td>${f0(d.wx)} km/h</td></tr>`).join('')}</tbody></table>`;
  $('#pt-range').textContent = `Next ${Math.round(SRC.steps[SRC.steps.length - 1] / 24)} days`;
}
const chart = $('#chart');
function drawChart() {
  if (!SERIES) return;
  const r = chart.getBoundingClientRect(), w = r.width, h = r.height, c = chart.getContext('2d');
  chart.width = Math.round(w * dpr); chart.height = Math.round(h * dpr); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
  const hrs = SERIES.hours, HM = hrs[hrs.length - 1], L = 30, Rm = 6;
  const panes = [['Temperature', '°C', 't2', 0, 0.36], ['Rain', 'mm/h', 'rain', 0.36, 0.66], ['Wind', 'km/h', 'ws', 0.66, 0.94]];
  const x = t => L + (w - L - Rm) * t / HM;
  c.font = '500 10px "Instrument Sans", system-ui, sans-serif'; c.textBaseline = 'middle';
  for (let t = 1; t <= HM; t++) { if (ist(t - 1).getUTCDate() !== ist(t).getUTCDate()) { c.fillStyle = THEME.muted; c.globalAlpha = 0.25; c.fillRect(x(t - 0.5), 0, 1, h * 0.94); c.globalAlpha = 1; } }
  for (const [name, unit, key, y0f, y1f] of panes) {
    const y0 = h * y0f + 14, y1 = h * y1f - 4, st = SERIES.stats[key];
    let lo = Infinity, hi = -Infinity; st.forEach(v => { if (!isNaN(v[0])) lo = Math.min(lo, v[0]); if (!isNaN(v[2])) hi = Math.max(hi, v[2]); });
    if (!isFinite(lo)) { lo = 0; hi = 1; }
    if (key !== 't2') lo = 0; if (key === 'rain') hi = Math.max(hi, 2); if (key === 'ws') hi = Math.max(hi, 20); if (key === 't2') { lo = Math.floor(lo - 1); hi = Math.ceil(hi + 1); }
    const y = v => y1 - (v - lo) / (hi - lo) * (y1 - y0);
    c.fillStyle = THEME.muted; c.textAlign = 'left'; c.fillText(`${name} (${unit})`, L + 2, y0 - 8);
    c.textAlign = 'right'; c.fillText(Math.round(hi), L - 5, y0); c.fillText(Math.round(lo), L - 5, y1);
    if (key === 'rain') {
      st.forEach((v, i) => {
        const bw = Math.max(1, ((i < hrs.length - 1 ? x(hrs[i + 1]) : x(hrs[i]) + 2) - x(hrs[i])) - 0.6);
        c.fillStyle = THEME.accent;
        if (v[2] > 0.05) { c.globalAlpha = 0.25; c.fillRect(x(hrs[i]) - bw / 2, y(v[2]), bw, y1 - y(v[2])); }
        if (v[1] > 0.05) { c.globalAlpha = 0.9; c.fillRect(x(hrs[i]) - bw / 2, y(v[1]), bw, y1 - y(v[1])); }
      });
      c.globalAlpha = 1;
    } else {
      const col = key === 't2' ? '#f08a36' : THEME.accent;
      c.beginPath(); st.forEach((v, i) => i ? c.lineTo(x(hrs[i]), y(v[2])) : c.moveTo(x(hrs[i]), y(v[2]))); for (let i = st.length - 1; i >= 0; i--) c.lineTo(x(hrs[i]), y(st[i][0])); c.closePath();
      c.fillStyle = col; c.globalAlpha = 0.22; c.fill(); c.globalAlpha = 1;
      c.beginPath(); st.forEach((v, i) => i ? c.lineTo(x(hrs[i]), y(v[1])) : c.moveTo(x(hrs[i]), y(v[1]))); c.strokeStyle = col; c.lineWidth = 1.8; c.stroke();
    }
    c.strokeStyle = THEME.muted; c.globalAlpha = 0.35; c.lineWidth = 1; c.beginPath(); c.moveTo(L, y1 + 0.5); c.lineTo(w - Rm, y1 + 0.5); c.stroke(); c.globalAlpha = 1;
  }
  let prev = -1; c.fillStyle = THEME.muted; c.textAlign = 'center';
  const minSpan = HM > 150 ? 20 : 8;
  for (let t = 0; t <= HM; t++) { const d = ist(t); if (d.getUTCDate() !== prev) { prev = d.getUTCDate(); const end = Math.min(HM, t + 24 - d.getUTCHours()); if (end - t >= minSpan) c.fillText(HM > 150 ? `${d.getUTCDate()}` : `${DAYS[d.getUTCDay()]} ${d.getUTCDate()}`, (x(t) + x(end)) / 2, h - 6); } }
  c.fillStyle = THEME.ink; c.fillRect(x(state.t) - 0.75, 4, 1.5, h * 0.94 - 4);
}
chart.addEventListener('click', e => { const r = chart.getBoundingClientRect(), HM = SRC.steps[SRC.steps.length - 1]; setHour((e.clientX - r.left - 30) / (r.width - 36) * HM); });

/* ================= refresh ================= */
let reqId = 0, isoKey = '';
async function refresh() {
  const my = ++reqId; state.t = SRC.steps[state.si];
  $('#t-label').textContent = fmtTime(state.t);
  $('#t-sub').textContent = `+${state.t} h from forecast run`;
  slider.setAttribute('aria-valuetext', fmtTime(state.t));
  const l = L_[state.layer], lg = $('#legend'), slow = setTimeout(() => lg.classList.add('loading'), 150);
  try {
    const wk = l.wind === 'up' ? 'up' : l.wind === '100' ? '100' : '10';
    const [F, Wd, P] = await Promise.all([
      SRC.field(state.layer, state.t, state),
      state.flow ? SRC.wind(wk, state.t, state.lev) : Promise.resolve(null),
      state.isob && isoKey !== state.t + '' ? SRC.field('mslp', state.t, state) : Promise.resolve(null)]);
    if (my !== reqId) return;
    renderField(l, F); legendMessage('');
    if (Wd) WIND = Wd;
    if (P) { ISO = contours(P.a.map(v => isNaN(v) ? 1010 : v), P.g, 2); isoKey = state.t + ''; }
  } catch (e) {
    if (my !== reqId) return; console.warn(e);
    FIELD = null; legendMessage(`${l.name} is not available for ${fmtShort(state.t)} IST in this run.`);
  } finally { clearTimeout(slow); if (my === reqId) lg.classList.remove('loading'); }
  updateStorm();
  if (SERIES) { updatePointNow(); drawChart(); }
  dirty = true;
  if (SRC.live && state.si + 1 < SRC.steps.length) SRC.field(state.layer, SRC.steps[state.si + 1], state).catch(() => {});
}

/* ================= interactions ================= */
const ptrs = new Map(); let drag = null, pinch = null, downAt = null;
mapEl.addEventListener('pointerdown', e => {
  mapEl.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 1) { drag = { x: e.clientX, y: e.clientY, cx: view.cx, cy: view.cy }; downAt = { x: e.clientX, y: e.clientY, t: performance.now() }; }
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), ppd: view.ppd }; downAt = null; }
});
mapEl.addEventListener('pointermove', e => {
  const r = mapEl.getBoundingClientRect();
  if (!ptrs.has(e.pointerId)) { if (e.pointerType === 'mouse') hover(e.clientX - r.left, e.clientY - r.top); return; }
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 2 && pinch) {
    const [a, b] = [...ptrs.values()], mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
    zoomAt(mx, my, pinch.ppd * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d / view.ppd);
  } else if (drag) {
    view.cx = drag.cx - (e.clientX - drag.x) / (view.ppd * KX); view.cy = drag.cy + (e.clientY - drag.y) / view.ppd;
    constrain(); resetParticles(); dirty = true; $('#tip').hidden = true;
  }
});
const up = e => {
  ptrs.delete(e.pointerId);
  if (downAt && ptrs.size === 0 && Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) < 6 && performance.now() - downAt.t < 500) {
    const r = mapEl.getBoundingClientRect(); openPoint(LON(e.clientX - r.left), LAT(e.clientY - r.top));
  }
  if (ptrs.size < 2) pinch = null; if (ptrs.size === 0) { drag = null; downAt = null; }
  else { const p = [...ptrs.values()][0]; drag = { x: p.x, y: p.y, cx: view.cx, cy: view.cy }; }
};
mapEl.addEventListener('pointerup', up); mapEl.addEventListener('pointercancel', up);
mapEl.addEventListener('pointerleave', () => $('#tip').hidden = true);
mapEl.addEventListener('wheel', e => { e.preventDefault(); const r = mapEl.getBoundingClientRect(); zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-e.deltaY * 0.0016)); }, { passive: false });
function zoomAt(sx, sy, f) {
  const lon = LON(sx), lat = LAT(sy); view.ppd = clamp(view.ppd * f, 8, 320);
  view.cx = lon - (sx - W / 2) / (view.ppd * KX); view.cy = lat + (sy - H / 2) / view.ppd; constrain(); resetParticles(); dirty = true;
}
function constrain() { view.cx = clamp(view.cx, 55, 105); view.cy = clamp(view.cy, -5, 38); }
function hover(x, y) {
  const tip = $('#tip'); if (!FIELD) return; const lon = LON(x), lat = LAT(y), l = L_[state.layer];
  const v = sample(FIELD.a, FIELD.g, lon, lat); if (isNaN(v)) { tip.hidden = true; return; }
  let s = `${fmtVal(l, v)} ${l.unit}`; if (l.kmh) s += ` (${Math.round(v * 3.6)} km/h)`; if (l.id === 'rain') s += `, ${rainClass(v).toLowerCase()}`;
  tip.textContent = s; tip.hidden = false; tip.style.transform = `translate(${Math.min(x + 14, W - tip.offsetWidth - 8)}px, ${y + 14}px)`;
}
function wire() {
  $('#zin').onclick = () => zoomAt(W / 2, H / 2, 1.5); $('#zout').onclick = () => zoomAt(W / 2, H / 2, 1 / 1.5);
  slider.addEventListener('input', () => setStep(+slider.value));
  $('#play').onclick = () => togglePlay();
  $('#pt-close').onclick = closePoint;
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#point').hidden) closePoint(); });
  $('#st-zoom').onclick = () => { const a = activeStorm(state.t) || (SRC.storms[0] && { st: stormAt(SRC.storms[0], SRC.storms[0].median[0][0]) }); if (!a) return; view.cx = a.st.x; view.cy = a.st.y; view.ppd = clamp(Math.max(view.ppd, 45), 8, 320); resetParticles(); dirty = true; };
  $('#st-strike').onclick = () => setLayer('strike');
  const search = $('#search');
  $('#cities').innerHTML = CITIES.map(c => `<option value="${c[0]}"></option>`).join('');
  $('#search-form').addEventListener('submit', e => {
    e.preventDefault(); const q = search.value.trim().toLowerCase(); if (!q) return;
    const c = CITIES.find(c => c[0].toLowerCase() === q) || CITIES.find(c => c[0].toLowerCase().startsWith(q));
    const msg = $('#search-msg');
    if (!c) { msg.textContent = 'No match. Try a district town such as Guntur, or tap the map.'; msg.hidden = false; setTimeout(() => msg.hidden = true, 3500); return; }
    msg.hidden = true; view.cx = c[2]; view.cy = c[1]; view.ppd = clamp(Math.max(view.ppd, 60), 8, 320); resetParticles(); openPoint(c[2], c[1], c[0]); search.blur();
  });
  $('#about-btn').onclick = () => $('#about').showModal();
  $('#about-close').onclick = () => $('#about').close();
  $('#opts-btn').onclick = () => { const s = $('#side'); const open = !s.classList.contains('open'); s.classList.toggle('open', open); $('#opts-btn').setAttribute('aria-expanded', open); };
  const themeChanged = () => { readTheme(); LUTfor = ''; refresh(); resetParticles(); if (SERIES) drawChart(); };
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);
  new MutationObserver(themeChanged).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  window.addEventListener('resize', () => { resize(); if (SERIES) drawChart(); });
}

/* ================= start ================= */
async function start() {
  readTheme(); resize();
  (function loop() { if (dirty) { drawBase(); dirty = false; } if (!reduceMotion) stepParticles(); requestAnimationFrame(loop); })();
  const fatal = $('#fatal');
  try {
    SRC = CFG.dataUrl ? new RealSource(CFG.dataUrl) : new DemoSource();
    await SRC.init();
  } catch (e) {
    console.error(e);
    $('#fatal-msg').textContent = `Could not load forecast data from ${CFG.dataUrl}. Check the data address in config and that the storage bucket allows this site (CORS). Details: ${e.message}`;
    fatal.hidden = false; return;
  }
  INIT = SRC.initMs;
  $('#run-label').textContent = SRC.runLabel;
  $('#run-mode').textContent = SRC.live ? `Live ${SRC.model.name} data, ${SRC.members} members` : 'Sample data for demonstration';
  $('#brand-sub').textContent = `Weather explorer on ${SRC.model.name}`;
  document.title = `Vaana weather explorer (${SRC.model.name})`;
  $('#attrib').textContent = SRC.live ? `${SRC.model.attribution} Experimental AI forecast; follow IMD for official warnings.` : 'Experimental AI forecast. Follow IMD for official warnings.';
  $('#step-note').hidden = SRC.stepHours <= 1;
  $('#step-note').textContent = `Forecast steps are ${SRC.stepHours} hours apart, so daily highs and lows are approximate.`;
  $('#run-mode').classList.toggle('live', SRC.live);
  $('#about-mode').innerHTML = SRC.live ? `Showing forecast run <strong>${SRC.runLabel}</strong> from <strong>${SRC.model.name}</strong> (${SRC.model.by}), ${SRC.members} ensemble members, processed by the Vaana ingest job. ${SRC.model.attribution}` : '<strong>This view runs on simulated sample data</strong>, including an invented cyclone, so it can be explored without a data connection. Nothing shown here is a real forecast.';
  if (!SRC.rainProducts.includes(state.prod)) state.prod = SRC.rainProducts[0];
  if (!SRC.chance.includes(state.thr)) state.thr = SRC.chance[0];
  if (!SRC.accum.includes(state.per)) state.per = SRC.accum[0];
  if (reduceMotion) state.flow = false;
  if (SRC.live) {   // open at the forecast step closest to the current time
    const nowH = (Date.now() - SRC.initMs) / 3600e3; let best = 0;
    SRC.steps.forEach((h, i) => { if (Math.abs(h - nowH) < Math.abs(SRC.steps[best] - nowH)) best = i; });
    state.si = best; slider.value = best;
  }
  buildRail(); buildOpts(); buildToggles(); buildTicks(); wire();
  await refresh(); togglePlay(false);
}
$('#fatal-retry').onclick = () => location.reload();
$('#fatal-demo').onclick = () => { const u = new URL(location.href); u.searchParams.delete('data'); u.searchParams.set('demo', '1'); location.href = u.toString(); };
start();
