/* ================= utilities ================= */
const D2R = Math.PI / 180, PI = Math.PI;
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const sm = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
const gau = x => Math.exp(-x * x);
function hash(i, j, k) {
  let h = Math.imul(i, 374761393) ^ Math.imul(j, 668265263) ^ Math.imul(k, 1440662683);
  h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296;
}
function noise3(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  const a = hash(xi, yi, zi), b = hash(xi + 1, yi, zi), c = hash(xi, yi + 1, zi), d = hash(xi + 1, yi + 1, zi);
  const e = hash(xi, yi, zi + 1), f = hash(xi + 1, yi, zi + 1), g = hash(xi, yi + 1, zi + 1), h = hash(xi + 1, yi + 1, zi + 1);
  const l1 = a + (b - a) * u, l2 = c + (d - c) * u, l3 = e + (f - e) * u, l4 = g + (h - g) * u;
  const m1 = l1 + (l2 - l1) * v, m2 = l3 + (l4 - l3) * v;
  return m1 + (m2 - m1) * w;
}
const fbm = (x, y, z) => 0.6 * noise3(x, y, z) + 0.3 * noise3(x * 2.03 + 17, y * 2.03 + 5, z * 1.7) + 0.1 * noise3(x * 4.1 + 3, y * 4.1 + 11, z * 2.3);

/* ================= geography ================= */
const parse = s => s.split('|').map(r => r.split(' ').map(p => p.split(',').map(Number)));
const LANDR = parse(LAND), BORDR = parse(BORD);
const mkGrid = d => ({ d, lon0: 55, lat1: 38, nx: Math.round(50 / d) + 1, ny: Math.round(43 / d) + 1 });
const G = mkGrid(0.25), GC = mkGrid(0.5), GF = mkGrid(0.125);

function rasterLand(g) {
  const c = document.createElement('canvas'); c.width = g.nx; c.height = g.ny;
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.beginPath();
  for (const r of LANDR) { r.forEach((p, k) => { const X = (p[0] - g.lon0) / g.d + 0.5, Y = (g.lat1 - p[1]) / g.d + 0.5; k ? x.lineTo(X, Y) : x.moveTo(X, Y); }); x.closePath(); }
  x.fill('evenodd');
  const d = x.getImageData(0, 0, g.nx, g.ny).data, m = new Float32Array(g.nx * g.ny);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4 + 3] / 255;
  return m;
}
const LM = rasterLand(GF);
function sample(arr, g, lon, lat) {
  const x = (lon - g.lon0) / g.d, y = (g.lat1 - lat) / g.d;
  if (x < 0 || y < 0 || x > g.nx - 1 || y > g.ny - 1) return NaN;
  const i = Math.min(Math.floor(x), g.nx - 2), j = Math.min(Math.floor(y), g.ny - 2), fx = x - i, fy = y - j, n = g.nx;
  const a = arr[j * n + i], b = arr[j * n + i + 1], c = arr[(j + 1) * n + i], d = arr[(j + 1) * n + i + 1];
  return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
}
const landAt = (lon, lat) => { const v = sample(LM, GF, lon, lat); return isNaN(v) ? 0 : v; };
const front = lon => lon < 84 ? 28 + (84 - lon) * 0.6 : 27.6 + (lon - 84) * 0.08;
const plat = (lon, lat) => { const f = front(lon); return sm(f, f + 2, lat) * sm(71, 75, lon) * (1 - sm(101, 104, lon)); };
function elev(lon, lat, L, P) {
  const lg = 76.9 - (lat - 8.5) * 0.29, wg = 950 * gau((lon - lg) / 0.55) * sm(7.5, 9, lat) * (1 - sm(20.5, 22, lat));
  const le = 78.6 + (lat - 13.5) * 0.62, eg = 550 * gau((lon - le) / 0.7) * sm(13, 14, lat) * (1 - sm(19.5, 21, lat));
  const dc = 380 * gau((lon - 77.5) / 3.2) * gau((lat - 16.5) / 5);
  return L * (P * 4600 + (1 - P) * (wg + eg + dc));
}
const dryf = (lon, lat, P) => clamp(sm(20, 26, lat) * sm(79, 72, lon) + sm(22, 26, lat) * sm(66, 62, lon) + 0.7 * P, 0, 1);
const moist = (lon, lat, dry) => clamp(0.75 + 0.45 * gau((lon - 74.5) / 2.2) * sm(8, 10, lat) * (1 - sm(19, 21, lat)) + 0.5 * gau((lon - 92) / 4) * gau((lat - 25.5) / 3) + 0.15 * gau((lon - 88) / 6) * gau((lat - 15) / 6) - 0.7 * dry - 0.25 * sm(2, -4, lat), 0.05, 1.4);

function statics(g) {
  const n = g.nx * g.ny, L = new Float32Array(n), E = new Float32Array(n), Dr = new Float32Array(n), P = new Float32Array(n), Det = new Float32Array(n);
  for (let j = 0; j < g.ny; j++) for (let i = 0; i < g.nx; i++) {
    const k = j * g.nx + i, lon = g.lon0 + i * g.d, lat = g.lat1 - j * g.d;
    const l = landAt(lon, lat), p = plat(lon, lat);
    L[k] = l; P[k] = p; E[k] = elev(lon, lat, l, p); Dr[k] = dryf(lon, lat, p);
    Det[k] = (fbm(lon * 2.5 + 5, lat * 2.5 + 9, 0.5) - 0.5) * 2.4 * l;
  }
  return { L, E, Dr, P, Det };
}
const SG = statics(G), SC = statics(GC); let SF = null;

/* ================= sample storm + ensemble ================= */
function rng(seed) { let s = seed >>> 0; return () => { s = (Math.imul(s ^ (s >>> 15), 2246822507) + 0x9e3779b9) | 0; s ^= s >>> 13; s = Math.imul(s, 3266489909); s ^= s >>> 16; return (s >>> 0) / 4294967296; }; }
const R0 = rng(20260924);
const gauss = () => { const u = R0() || 1e-9, v = R0(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * PI * v); };
const NM = 16, MP = [{ a: 0, c: 0, i: 0 }];
for (let m = 1; m < NM; m++) MP.push({ a: gauss(), c: gauss(), i: gauss() });
const TRK = [[-24, 90.3, 9.9, 15], [0, 88.6, 11.2, 22], [24, 86.9, 12.6, 32], [48, 84.3, 14.4, 42], [66, 82.4, 15.6, 46], [76, 81.2, 16.4, 43], [96, 79.6, 17.6, 21], [120, 77.6, 19.0, 12], [150, 75.6, 20.3, 8]];
const cr = (a, b, c, d, t) => 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t * t * t);
function trackAt(t) {
  t = clamp(t, -24, 150); let k = 0; while (k < TRK.length - 2 && TRK[k + 1][0] < t) k++;
  const p0 = TRK[Math.max(0, k - 1)], p1 = TRK[k], p2 = TRK[k + 1], p3 = TRK[Math.min(TRK.length - 1, k + 2)], f = (t - p1[0]) / (p2[0] - p1[0]);
  return { x: cr(p0[1], p1[1], p2[1], p3[1], f), y: cr(p0[2], p1[2], p2[2], p3[2], f), v: p1[3] + (p2[3] - p1[3]) * f };
}
function stormState(t, m) {
  const p = MP[m], te = t + p.a * 0.075 * Math.max(0, t), c = trackAt(te), c2 = trackAt(te + 1);
  const mx = c2.x - c.x, my = c2.y - c.y, ml = Math.hypot(mx, my) || 1e-6, off = p.c * 0.011 * Math.max(0, t);
  const v = Math.max(0, c.v * (1 + 0.1 * p.i));
  return { x: c.x - my / ml * off, y: c.y + mx / ml * off, v, dp: v * v / 48, mx, my };
}
const HMAX = 120;
const TRACKS = [];
for (let m = 0; m < NM; m++) { const a = []; for (let t = 0; t <= HMAX; t++) a.push(stormState(t, m)); TRACKS.push(a); }
const PAST = []; for (let t = -24; t <= 0; t++) PAST.push(trackAt(t));

/* ================= physics-flavoured sample fields ================= */
function rainAt(lon, lat, t, st, m, L, dry) {
  const cl = Math.cos(lat * D2R), dx = (lon - st.x) * cl, dy = lat - st.y, r = Math.sqrt(dx * dx + dy * dy) + 1e-4, f = st.v / 45;
  let rs = 0;
  if (f > 0.05 && r < 9) {
    const th = Math.atan2(dy, dx), mth = Math.atan2(st.my, st.mx * cl), asym = 1 + 0.35 * Math.cos(th - mth - 0.6);
    const tex = clamp(0.5 + (fbm(lon * 1.4 + m * 3.1, lat * 1.4, t * 0.25) - 0.5) * 1.9, 0, 1.25);
    const eye = 38 * f * gau((r - 0.5) / 0.32), core = 10 * f * gau(r / 1.7);
    const band = Math.pow(Math.max(0, Math.sin(th * 2 - 4.2 * Math.log(r + 0.25) + t * 0.12)), 3) * 16 * f * Math.exp(-r / 3) * sm(0.5, 1, r);
    rs = (eye + core + band) * asym * (0.3 + tex) * sm(0.07, 0.22, r);
  }
  const lst = ((t + lon / 15) % 24 + 24) % 24, mo = moist(lon, lat, dry);
  const c = (fbm(lon * 0.45 + m * 5.3, lat * 0.45 + 2, t * 0.35) - 0.5) * 1.7 + 0.5;
  const di = L * Math.max(0, Math.cos((lst - 16) * PI / 12)) + (1 - L) * (0.35 + 0.25 * Math.cos((lst - 5) * PI / 12));
  let rc = Math.max(0, c - 0.7) * 48 * mo * (0.15 + di);
  if (f > 0.05) rc *= 1 - 0.7 * gau((r - 5) / 2) * Math.min(1, f);
  return rs + rc;
}
function wakeAt(lon, lat, t) {
  let w = 0; const cl = Math.cos(lat * D2R);
  for (let s = -24; s <= t; s += 3) {
    const p = s <= 0 ? PAST[s + 24] : TRACKS[0][s]; if (p.v < 18) continue;
    const dx = (lon - p.x) * cl, dy = lat - p.y, d2 = dx * dx + dy * dy; if (d2 > 4) continue;
    w = Math.min(w, -2.2 * (p.v / 45) * Math.exp(-d2 / 0.6) * sm(0, 18, t - s));
  }
  return w;
}
function sfc(lon, lat, t, st, m, L, E, dry, P, wk, o) {
  const cl = Math.cos(lat * D2R), dx = (lon - st.x) * cl, dy = lat - st.y, r = Math.sqrt(dx * dx + dy * dy) + 1e-4, f = st.v / 45;
  const lst = ((t + lon / 15) % 24 + 24) % 24;
  const R = 0.45, vt = st.v * (r < R ? r / R : Math.pow(R / r, 0.55)) * Math.exp(-r / 9), inf = 0.28 + 0.2 * L;
  const us = vt * (-dy / r - inf * dx / r), vs = vt * (dx / r - inf * dy / r);
  const nu = fbm(lon * 0.16 + 3, lat * 0.16, t * 0.03 + m * 0.37) - 0.5, nv = fbm(lon * 0.16 + 40, lat * 0.16 + 9, t * 0.03 + m * 0.37) - 0.5;
  const ub = 6.5 * gau((lat - 13) / 6) - 4.5 * sm(3, -6, lat) + 7 * sm(28, 35, lat) - 1.5 * gau((lat - 24) / 3) + 6 * nu;
  const vb = 2.2 * gau((lat - 12) / 7) + 3 * sm(3, -6, lat) + 5 * nv;
  const fr = (1 - 0.32 * L) * (1 - 0.45 * P);
  o.u10 = (us + ub) * fr; o.v10 = (vs + vb) * fr;
  const h = 1.1 + 0.28 * L; o.u100 = o.u10 * h; o.v100 = o.v10 * h;
  const rain = rainAt(lon, lat, t, st, m, L, dry);
  o.rain = rain; o.imerg = rain * 0.9; o.exp = Math.pow(rain, 1.08) * 1.04;
  const mo = moist(lon, lat, dry), fs = Math.min(1, f * 1.3);
  const cn = fbm(lon * 0.25 + 11, lat * 0.25 + 7, t * 0.05 + m), cc = (fbm(lon * 0.45 + m * 5.3, lat * 0.45 + 2, t * 0.35) - 0.5) * 1.7 + 0.5;
  o.hcc = clamp(1.05 * Math.exp(-Math.pow(r / 4.2, 1.6)) * fs + rain / 12 + 0.9 * Math.max(0, cn - 0.55) * mo, 0, 1);
  o.mcc = clamp(0.9 * gau(r / 2.6) * fs + rain / 8 + 0.8 * Math.max(0, cc - 0.5) * mo, 0, 1);
  o.lcc = clamp(rain / 5 + 0.55 * Math.max(0, cc - 0.42) * mo + (1 - L) * 0.12 * mo + 0.3 * gau(r / 3) * fs, 0, 1);
  o.tcc = 1 - (1 - o.lcc) * (1 - o.mcc) * (1 - o.hcc);
  const sst = 28.4 + 1.1 * gau((lon - 88) / 7) * gau((lat - 14) / 8) - 0.14 * Math.max(0, 5 - lat) - 0.9 * gau((lon - 60) / 5) * gau((lat - 14) / 7) + 0.4 * gau((lon - 72) / 6) * gau((lat - 12) / 6) + wk;
  o.sst = sst;
  const pk = Math.cos((lst - 14.5) * PI / 12), A = (3.5 + 3.5 * dry) * (1 - 0.65 * o.tcc);
  const Tl = 28.2 + 1.8 * dry - 5.0 * E / 1000 + A * pk - 3.5 * Math.min(1, rain / 6);
  const To = sst - 0.5 + 0.35 * pk - 1.8 * Math.min(1, rain / 8);
  o.t2 = L * Tl + (1 - L) * To;
  o.td2 = o.t2 - (L * (3 + 11 * dry + 0.6 * A * Math.max(0, pk)) + (1 - L) * 2.2) * (1 - 0.75 * Math.min(1, rain / 3));
  o.mslp = 1008.5 - 5.5 * gau((lon - 70) / 9) * gau((lat - 28) / 5) + 3 * sm(8, -5, lat) + 1.5 * sm(30, 38, lat) + 0.8 * Math.cos((lst - 10) * PI / 6) + (cn - 0.5) * 2 - st.dp / (1 + Math.pow(r / 0.75, 1.6));
  const ha = (lst - 12.5) * 15 * D2R, ph = lat * D2R, dec = -0.4 * D2R;
  const cz = Math.sin(ph) * Math.sin(dec) + Math.cos(ph) * Math.cos(dec) * Math.cos(ha);
  if (cz > 0.01) { const clr = 1098 * cz * Math.exp(-0.057 / cz); o.ghi = clr * (1 - 0.75 * Math.pow(o.tcc, 3.4)); o.dir = clr * 0.8 * Math.pow(1 - o.tcc, 1.6); }
  else { o.ghi = 0; o.dir = 0; }
}
const rhOf = (T, Td) => clamp(100 * Math.exp(17.625 * Td / (243.04 + Td)) / Math.exp(17.625 * T / (243.04 + T)), 0, 100);
function feelsOf(T, RH, ws) {
  if (T >= 27 && RH >= 40) {
    const F = T * 1.8 + 32, H = -42.379 + 2.04901523 * F + 10.14333127 * RH - 0.22475541 * F * RH - 0.00683783 * F * F - 0.05481717 * RH * RH + 0.00122874 * F * F * RH + 0.00085282 * F * RH * RH - 0.00000199 * F * F * RH * RH;
    return (H - 32) / 1.8;
  }
  if (T <= 10 && ws > 1.34) { const v = Math.pow(ws * 3.6, 0.16); return 13.12 + 0.6215 * T - 11.37 * v + 0.3965 * T * v; }
  return T;
}

/* ================= grid computations (cached) ================= */
const KEYS = ['u10', 'v10', 'u100', 'v100', 'rain', 'imerg', 'exp', 'hcc', 'mcc', 'lcc', 'tcc', 'sst', 't2', 'td2', 'mslp', 'ghi', 'dir'];
function computeSfcGrid(g, S, t, fine) {
  const n = g.nx * g.ny, out = {}; KEYS.forEach(k => out[k] = new Float32Array(n));
  const st = stormState(t, 0), o = {};
  for (let j = 0; j < g.ny; j++) for (let i = 0; i < g.nx; i++) {
    const k = j * g.nx + i, lon = g.lon0 + i * g.d, lat = g.lat1 - j * g.d, L = S.L[k];
    const wk = L < 0.9 ? wakeAt(lon, lat, t) : 0;
    sfc(lon, lat, t, st, 0, L, S.E[k], S.Dr[k], S.P[k], wk, o);
    if (fine) { o.t2 += S.Det[k]; o.td2 += S.Det[k] * 0.7; }
    for (const key of KEYS) out[key][k] = o[key];
  }
  return out;
}
let S = null, St = -1, SFt = -1, SFd = null;
const getSfc = t => { if (St !== t) { S = computeSfcGrid(G, SG, t, false); St = t; } return S; };
const getFine = t => { if (!SF) SF = statics(GF); if (SFt !== t) { SFd = computeSfcGrid(GF, SF, t, true); SFt = t; } return SFd; };

const LEVS = [1000, 925, 850, 700, 600, 500, 400, 300, 250, 200, 150, 100, 50];
const TSTD = [28.5, 24, 19.5, 10.5, 4.5, -4.5, -14.5, -30.5, -40, -52, -66, -79, -67];
const ZSTD = [100, 780, 1510, 3160, 4410, 5880, 7600, 9700, 10950, 12450, 14250, 16650, 20700];
let Up = null, UpKey = '';
function getUpper(t, p) {
  const key = t + '_' + p; if (key === UpKey) return Up;
  const s = getSfc(t), li = LEVS.indexOf(p), n = G.nx * G.ny, st = stormState(t, 0), f = st.v / 45;
  const U = { u: new Float32Array(n), v: new Float32Array(n), T: new Float32Array(n), Z: new Float32Array(n), q: new Float32Array(n), w: new Float32Array(n) };
  const lw = clamp((p - 300) / 550, 0, 1), l2 = clamp((p - 600) / 400, 0, 1), lp = Math.log(p);
  const hw = gau((lp - Math.log(200)) / 0.5), tej = gau((lp - Math.log(130)) / 0.45), stj = gau((lp - Math.log(200)) / 0.55), mid = gau((lp - Math.log(450)) / 0.5);
  const wc = gau((lp - Math.log(380)) / 0.5), zl = clamp((p - 250) / 750, 0, 1), tib = gau((lp - Math.log(200)) / 0.6), shape = Math.sin(PI * clamp((1000 - p) / 900, 0, 1));
  for (let j = 0; j < G.ny; j++) for (let i = 0; i < G.nx; i++) {
    const k = j * G.nx + i, lon = G.lon0 + i * G.d, lat = G.lat1 - j * G.d, cl = Math.cos(lat * D2R);
    const dx = (lon - st.x) * cl, dy = lat - st.y, r = Math.sqrt(dx * dx + dy * dy) + 1e-4;
    const vo = 9 * f * (r / 2) * Math.exp(-r / 2.5) * hw;
    const tx = (lon - 88) * cl, ty = lat - 28, ta = 10 * tib * Math.exp(-(tx * tx + ty * ty) / 81) / 7;
    const nz = fbm(lon * 0.12 + 70, lat * 0.12 + p * 0.01, t * 0.02) - 0.5;
    U.u[k] = lw * s.u10[k] * 1.35 - 17 * gau((lat - 9) / 6) * tej + 36 * gau((lat - 34) / 4.5) * stj + 10 * sm(25, 33, lat) * mid + vo * (dy / r + 0.6 * dx / r) + ta * ty + 5 * nz * (1 - lw);
    U.v[k] = lw * s.v10[k] * 1.35 + vo * (-dx / r + 0.6 * dy / r) - ta * tx + 4 * nz;
    U.T[k] = TSTD[li] + (s.t2[k] - 28.5) * l2 - (p >= 150 ? 0.45 * Math.max(0, lat - 24) * (1 - l2) : 0) + 7 * f * gau(r / 1.3) * wc + 3 * SG.P[k] * gau((lp - Math.log(400)) / 0.4);
    U.Z[k] = ZSTD[li] + (s.mslp[k] - 1008) * 8.3 * zl + 45 * f * gau(r / 2) * (1 - lw) - 70 * sm(24, 38, lat) * (1 - l2) + 50 * gau((lon - 88) / 12) * gau((lat - 29) / 6) * tib;
    const e = 6.112 * Math.exp(17.67 * s.td2[k] / (s.td2[k] + 243.5)), qs = 622 * e / (1010 - 0.378 * e);
    U.q[k] = Math.max(0.005, qs * Math.pow(p / 1000, 3) * (1 + 0.8 * Math.min(1, s.rain[k] / 5) * gau((lp - Math.log(600)) / 0.5)));
    U.w[k] = shape * (0.05 - 0.11 * Math.min(4, s.rain[k] / 3));
  }
  Up = U; UpKey = key; return U;
}
let Acc = null, AccKey = '';
function getAccum(t, per) {
  const key = t + '_' + per; if (key === AccKey) return Acc;
  const n = G.nx * G.ny, a = new Float32Array(n), end = Math.min(HMAX, t + per), dt = per <= 3 ? 1 : per <= 24 ? 3 : 6;
  for (let s = t + dt; s <= end + 1e-6; s += dt) {
    const st = stormState(s, 0);
    for (let j = 0; j < G.ny; j++) for (let i = 0; i < G.nx; i++) { const k = j * G.nx + i; a[k] += rainAt(G.lon0 + i * G.d, G.lat1 - j * G.d, s, st, 0, SG.L[k], SG.Dr[k]) * dt; }
  }
  Acc = a; AccKey = key; return a;
}
let Ch = null, ChKey = '';
function getChance(t, thr) {
  const key = t + '_' + thr; if (key === ChKey) return Ch;
  const n = GC.nx * GC.ny, cnt = new Float32Array(n), end = Math.min(HMAX, t + 24), dt = 4, tot = new Float32Array(n);
  for (let m = 0; m < NM; m++) {
    tot.fill(0);
    for (let s = t + dt; s <= end + 1e-6; s += dt) {
      const st = stormState(s, m);
      for (let j = 0; j < GC.ny; j++) for (let i = 0; i < GC.nx; i++) { const k = j * GC.nx + i; tot[k] += rainAt(GC.lon0 + i * GC.d, GC.lat1 - j * GC.d, s, st, m, SC.L[k], SC.Dr[k]) * dt; }
    }
    for (let k = 0; k < n; k++) if (tot[k] >= thr) cnt[k]++;
  }
  for (let k = 0; k < n; k++) cnt[k] = cnt[k] / NM * 100;
  Ch = cnt; ChKey = key; return cnt;
}
let Strike = null;
function getStrike() {
  if (Strike) return Strike;
  const n = GC.nx * GC.ny, a = new Float32Array(n);
  for (let j = 0; j < GC.ny; j++) for (let i = 0; i < GC.nx; i++) {
    const lon = GC.lon0 + i * GC.d, lat = GC.lat1 - j * GC.d, cl = Math.cos(lat * D2R); let c = 0;
    if (lon < 70 || lon > 96 || lat < 5 || lat > 26) continue;
    for (let m = 0; m < NM; m++) { for (const p of TRACKS[m]) { if (p.v < 8.7) continue; const dx = (lon - p.x) * cl, dy = lat - p.y; if (dx * dx + dy * dy < 1) { c++; break; } } }
    a[j * GC.nx + i] = c / NM * 100;
  }
  return (Strike = a);
}
