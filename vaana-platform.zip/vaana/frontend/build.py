"""Builds the Vaana frontend.

  python build.py            -> dist/index.html + dist/config.js (for hosting with live data)
                                dist/vaana-demo.html (single file, demo data only)
"""
import glob, os
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, "src")
parts = sorted(p for p in glob.glob(os.path.join(src, "*.js")))
app = "(() => {\n'use strict';\n" + "\n".join(open(p).read() for p in parts) + "\n})();"
shell = open(os.path.join(src, "shell.html")).read()
os.makedirs(os.path.join(here, "dist"), exist_ok=True)
hosted = shell.replace("/*CONFIG*/", '<script src="config.js"></script>').replace("/*APP*/", app)
open(os.path.join(here, "dist", "index.html"), "w").write(hosted)
cfg = os.path.join(here, "dist", "config.js")
if not os.path.exists(cfg):
    open(cfg, "w").write("// Address of the bucket the ingest job writes to. Leave empty to run the demo.\n"
                         "window.VAANA_CONFIG = { dataUrl: '' };\n")
demo = shell.replace("/*CONFIG*/", "<script>window.VAANA_CONFIG = { dataUrl: '' };</script>").replace("/*APP*/", app)
open(os.path.join(here, "dist", "vaana-demo.html"), "w").write(demo)
print("built", len(app) // 1024, "KB of script")
