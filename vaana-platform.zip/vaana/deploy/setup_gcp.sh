#!/usr/bin/env bash
# One-time setup of the Vaana backend on Google Cloud, then (re)deploys the ingest job.
# Needs: gcloud CLI logged in as a project owner.  Usage:  bash setup_gcp.sh
set -euo pipefail
cd "$(dirname "$0")"
source settings.env
SA="vaana-ingest@${PROJECT_ID}.iam.gserviceaccount.com"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/vaana/ingest:latest"
gcloud config set project "$PROJECT_ID"

echo "== Enabling services"
gcloud services enable run.googleapis.com cloudscheduler.googleapis.com artifactregistry.googleapis.com \
  cloudbuild.googleapis.com storage.googleapis.com

echo "== Service account for the ingest job"
gcloud iam service-accounts describe "$SA" >/dev/null 2>&1 || \
  gcloud iam service-accounts create vaana-ingest --display-name "Vaana ingest job"

echo "== Data bucket"
gcloud storage buckets describe "gs://${DATA_BUCKET}" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://${DATA_BUCKET}" --location="$REGION" --uniform-bucket-level-access
sed "s#https://YOUR-SITE.web.app#${SITE_URL}#" cors.json > /tmp/vaana-cors.json
gcloud storage buckets update "gs://${DATA_BUCKET}" --cors-file=/tmp/vaana-cors.json --lifecycle-file=lifecycle.json
gcloud storage buckets add-iam-policy-binding "gs://${DATA_BUCKET}" --member="serviceAccount:${SA}" --role=roles/storage.objectAdmin
if [ "$PUBLIC_DATA" = "yes" ]; then
  gcloud storage buckets add-iam-policy-binding "gs://${DATA_BUCKET}" --member=allUsers --role=roles/storage.objectViewer
fi

echo "== Build the ingest image"
gcloud artifacts repositories describe vaana --location="$REGION" >/dev/null 2>&1 || \
  gcloud artifacts repositories create vaana --repository-format=docker --location="$REGION"
gcloud builds submit ../ingest --tag "$IMAGE"

echo "== Cloud Run job"
ENVV="VAANA_SOURCE=${VAANA_SOURCE},VAANA_OUT=gs://${DATA_BUCKET}"
[ -n "$WN_SFC_URL" ] && ENVV="${ENVV},WN_SFC_URL=${WN_SFC_URL}"
[ -n "$WN_STN_URL" ] && ENVV="${ENVV},WN_STN_URL=${WN_STN_URL}"
[ -n "$WN_PL_URL" ] && ENVV="${ENVV},WN_PL_URL=${WN_PL_URL}"
if gcloud run jobs describe vaana-ingest --region "$REGION" >/dev/null 2>&1; then CMD=update; else CMD=create; fi
gcloud run jobs "$CMD" vaana-ingest --region "$REGION" --image "$IMAGE" --service-account "$SA" \
  --cpu "$JOB_CPU" --memory "$JOB_MEMORY" --task-timeout "$JOB_TIMEOUT" --max-retries 1 \
  --set-env-vars "$ENVV"
gcloud run jobs add-iam-policy-binding vaana-ingest --region "$REGION" --member="serviceAccount:${SA}" --role=roles/run.invoker

echo "== Hourly schedule"
URI="https://run.googleapis.com/v2/projects/${PROJECT_ID}/locations/${REGION}/jobs/vaana-ingest:run"
if gcloud scheduler jobs describe vaana-hourly --location "$REGION" >/dev/null 2>&1; then SCMD=update; else SCMD=create; fi
gcloud scheduler jobs "$SCMD" http vaana-hourly --location "$REGION" --schedule "$SCHEDULE" --time-zone "Etc/UTC" \
  --uri "$URI" --http-method POST --oauth-service-account-email "$SA"

cat <<MSG

Done. Next:
 1. (WeatherNext only) ask Google to allowlist ${SA} so the job can read the data.
 2. Run the first ingest now:  gcloud run jobs execute vaana-ingest --region ${REGION} --wait
 3. Deploy the website:       bash deploy_site.sh
MSG
