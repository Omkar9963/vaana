#!/usr/bin/env bash
# Builds the website and publishes it on Firebase Hosting.
# Needs: firebase CLI (npm i -g firebase-tools), logged in, Firebase added to the GCP project.
set -euo pipefail
cd "$(dirname "$0")"
source settings.env
python3 ../frontend/build.py
printf "// Written by deploy_site.sh\nwindow.VAANA_CONFIG = { dataUrl: 'https://storage.googleapis.com/%s' };\n" "$DATA_BUCKET" > ../frontend/dist/config.js
firebase deploy --only hosting --project "$PROJECT_ID" --config firebase.json
