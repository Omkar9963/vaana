"""Build small synthetic Zarr stores shaped like WeatherNext 3 output, for testing the pipeline
without real data. Includes a moving cyclone so the tracker has something to find.

Usage:  python tests/make_fake_run.py /tmp/wn 2026092400
"""
import sys
import numpy as np
import pandas as pd
import xarray as xr

out, init = sys.argv[1], sys.argv[2]
it = pd.Timestamp(init[:8] + "T" + init[8:] + ":00")
M, LEADS = 6, np.arange(0, 49)
rng = np.random.default_rng(1)
off = rng.normal(size=(M, 3))


def storm(h, m):
    x = 88.6 - 0.1 * h + off[m, 0] * 0.012 * h
    y = 11.2 + 0.07 * h + off[m, 1] * 0.012 * h
    v = min(45, 22 + 0.6 * h) * (1 + 0.08 * off[m, 2])
    return x, y, v


def fields(lat, lon, h, m):
    LON, LAT = np.meshgrid(lon, lat)
    x, y, v = storm(h, m)
    cl = np.cos(np.radians(LAT))
    dx, dy = (LON - x) * cl, LAT - y
    r = np.hypot(dx, dy) + 1e-4
    R = 0.45
    vt = v * np.where(r < R, r / R, (R / r) ** 0.55) * np.exp(-r / 9)
    u = vt * (-dy / r - 0.3 * dx / r) + 6 * np.exp(-((LAT - 13) / 6) ** 2)
    vv = vt * (dx / r - 0.3 * dy / r) + 2
    p = 1008.5 - (v * v / 48) / (1 + (r / 0.75) ** 1.6)
    rain = 35 * (v / 45) * np.exp(-((r - 0.5) / 0.35) ** 2) + 8 * np.exp(-(r / 2) ** 2) + np.maximum(0, np.sin(LON * 1.3 + h * 0.3) * np.cos(LAT * 1.1) - 0.7) * 20
    lst = (h + LON / 15) % 24
    t = 300.5 + 4 * np.cos((lst - 14.5) * np.pi / 12) - 3 * np.minimum(1, rain / 6)
    cloud = np.clip(rain / 6 + 0.9 * np.exp(-(r / 3) ** 2), 0, 1)
    return u, vv, p * 100, rain / 1000, t, cloud


def build(lat, lon, names, levels=None):
    shape = (len(LEADS), M, len(lat), len(lon))
    data = {n: np.zeros(shape, np.float32) for n in names}
    for i, h in enumerate(LEADS):
        for m in range(M):
            u, v, p, r, t, c = fields(lat, lon, int(h), m)
            vals = {"u_component_of_wind_10m": u, "v_component_of_wind_10m": v, "u_component_of_wind_100m": u * 1.2,
                    "v_component_of_wind_100m": v * 1.2, "mean_sea_level_pressure": p, "total_precipitation_1hr": r,
                    "imerg_tp_1hr": r * 0.9, "experimental_tp_1hr": r * 1.05, "temperature_2m": t, "dewpoint_temperature_2m": t - 3,
                    "total_cloud_cover": c, "low_cloud_cover": c * 0.8, "medium_cloud_cover": c * 0.7, "high_cloud_cover": c * 0.9,
                    "sea_surface_temperature": np.full_like(t, 302.0), "surface_solar_radiation_downwards_1hr": (1 - c) * 2.5e6,
                    "total_sky_direct_solar_radiation_at_surface_1hr": (1 - c) * 1.8e6,
                    "station_head_temperature_2m": t + 0.3, "station_head_dewpoint_temperature_2m": t - 2.7}
            for n in names:
                data[n][i, m] = vals[n]
    return data


lead = pd.to_timedelta(LEADS, unit="h")
# surface: 0.25 deg (real data is 0.1), wider than the app domain, latitude descending
lat, lon = np.arange(40, -8.01, -0.25), np.arange(50, 110.01, 0.25)
names = ["u_component_of_wind_10m", "v_component_of_wind_10m", "u_component_of_wind_100m", "v_component_of_wind_100m",
         "mean_sea_level_pressure", "total_precipitation_1hr", "imerg_tp_1hr", "experimental_tp_1hr", "temperature_2m",
         "dewpoint_temperature_2m", "total_cloud_cover", "low_cloud_cover", "medium_cloud_cover", "high_cloud_cover",
         "sea_surface_temperature", "surface_solar_radiation_downwards_1hr", "total_sky_direct_solar_radiation_at_surface_1hr"]
d = build(lat, lon, names)
ds = xr.Dataset({n: (("lead_time", "ensemble_member", "latitude", "longitude"), a) for n, a in d.items()},
                coords=dict(lead_time=lead, ensemble_member=np.arange(M), latitude=lat, longitude=lon))
ds.chunk({"lead_time": 1}).to_zarr(f"{out}/sfc_{init}.zarr", mode="w")
# station grid 0.125, latitude ascending
lat2, lon2 = np.arange(-6, 39.01, 0.125), np.arange(54, 106.01, 0.125)
d = build(lat2, lon2, ["station_head_temperature_2m", "station_head_dewpoint_temperature_2m"])
xr.Dataset({n: (("lead_time", "ensemble_member", "latitude", "longitude"), a) for n, a in d.items()},
           coords=dict(lead_time=lead, ensemble_member=np.arange(M), latitude=lat2, longitude=lon2)
           ).chunk({"lead_time": 1}).to_zarr(f"{out}/stn_{init}.zarr", mode="w")
# pressure levels 0.5 deg, 6-hourly
lat3, lon3 = np.arange(40, -8.01, -0.5), np.arange(50, 110.01, 0.5)
LEV = [1000, 925, 850, 700, 600, 500, 400, 300, 250, 200, 150, 100, 50]
pl_leads = LEADS[::6]
shape = (len(pl_leads), M, len(LEV), len(lat3), len(lon3))
T = np.zeros(shape, np.float32); U = np.zeros(shape, np.float32); V = np.zeros(shape, np.float32)
for i, h in enumerate(pl_leads):
    for m in range(M):
        u, v, p, r, t, c = fields(lat3, lon3, int(h), m)
        for k, lv in enumerate(LEV):
            f = max(0, (lv - 300) / 700)
            T[i, m, k] = t - 6.5 * 8 * np.log(1000 / lv)
            U[i, m, k] = u * f + (1 - f) * 20
            V[i, m, k] = v * f
Z = np.broadcast_to((np.array([100, 780, 1510, 3160, 4410, 5880, 7600, 9700, 10950, 12450, 14250, 16650, 20700]) * 9.80665)[None, None, :, None, None], shape).astype(np.float32)
dims = ("lead_time", "ensemble_member", "level", "latitude", "longitude")
xr.Dataset({"temperature": (dims, T), "u_component_of_wind": (dims, U), "v_component_of_wind": (dims, V),
            "geopotential": (dims, Z.copy()), "specific_humidity": (dims, np.full(shape, 0.012, np.float32)),
            "vertical_velocity": (dims, np.full(shape, -0.1, np.float32))},
           coords=dict(lead_time=pd.to_timedelta(pl_leads, unit="h"), ensemble_member=np.arange(M), level=LEV,
                       latitude=lat3, longitude=lon3)).chunk({"lead_time": 1}).to_zarr(f"{out}/pl_{init}.zarr", mode="w")
print("fake run written to", out)
