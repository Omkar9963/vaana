"""Synthetic store shaped like dynamical.org's ECMWF AIFS ENS dataset (for tests without internet).

One Zarr store, dims init_time x lead_time x ensemble_member x latitude x longitude,
6-hourly steps, 0.25 degree, latitude descending, longitude -180..180 convention,
units as published: °C, Pa, %, W/m², precipitation in kg m-2 s-1 (= mm/s).
The newest init is left incomplete to check that the job picks the last complete run.

Usage:  python tests/make_fake_aifs.py /tmp/aifs.zarr
"""
import sys
import numpy as np
import pandas as pd
import xarray as xr

out = sys.argv[1]
M, LEADS = 8, np.arange(0, 97, 6)
inits = pd.to_datetime(["2026-09-23T18:00", "2026-09-24T00:00", "2026-09-24T06:00"])
lat, lon = np.arange(40, -10.01, -0.25), np.arange(40, 120.01, 0.25)
rng = np.random.default_rng(3)
off = rng.normal(size=(M, 3))
LON, LAT = np.meshgrid(lon, lat)
cl = np.cos(np.radians(LAT))
shape = (len(inits), len(LEADS), M, len(lat), len(lon))
names = ["temperature_2m", "dew_point_temperature_2m", "wind_u_10m", "wind_v_10m", "wind_u_100m", "wind_v_100m",
         "downward_short_wave_radiation_flux_surface", "precipitation_surface", "total_cloud_cover_atmosphere",
         "pressure_reduced_to_mean_sea_level", "temperature_850hpa", "temperature_925hpa",
         "geopotential_height_500hpa", "geopotential_height_850hpa", "geopotential_height_925hpa"]
data = {n: np.full(shape, np.nan, np.float32) for n in names}
for ii, it in enumerate(inits):
    base_h = (it - inits[1]) / pd.Timedelta(hours=1)
    for li, h in enumerate(LEADS):
        if ii == 2 and h > 48:
            continue                                     # newest run still being written
        for m in range(M):
            hh = h + base_h
            x = 88.6 - 0.1 * hh + off[m, 0] * 0.012 * h
            y = 11.2 + 0.07 * hh + off[m, 1] * 0.012 * h
            v = min(45, 22 + 0.6 * max(hh, 0)) * (1 + 0.08 * off[m, 2])
            dx, dy = (LON - x) * cl, LAT - y
            r = np.hypot(dx, dy) + 1e-4
            vt = v * np.where(r < 0.45, r / 0.45, (0.45 / r) ** 0.55) * np.exp(-r / 9)
            u = vt * (-dy / r - 0.3 * dx / r) + 6 * np.exp(-((LAT - 13) / 6) ** 2)
            vv = vt * (dx / r - 0.3 * dy / r) + 2
            p = 1008.5 - (v * v / 48) / (1 + (r / 0.75) ** 1.6)
            rain_mmh = 30 * (v / 45) * np.exp(-((r - 0.5) / 0.4) ** 2) + 6 * np.exp(-(r / 2) ** 2)
            lst = (h + LON / 15) % 24
            t = 27.5 + 4 * np.cos((lst - 14.5) * np.pi / 12) - 3 * np.minimum(1, rain_mmh / 6)
            cloud = np.clip(rain_mmh / 6 + 0.9 * np.exp(-(r / 3) ** 2), 0, 1) * 100
            vals = dict(temperature_2m=t, dew_point_temperature_2m=t - 3, wind_u_10m=u, wind_v_10m=vv,
                        wind_u_100m=u * 1.2, wind_v_100m=vv * 1.2, downward_short_wave_radiation_flux_surface=(100 - cloud) * 5,
                        precipitation_surface=np.nan * t if h == 0 else rain_mmh / 3600, total_cloud_cover_atmosphere=cloud,
                        pressure_reduced_to_mean_sea_level=p * 100, temperature_850hpa=t - 10, temperature_925hpa=t - 5,
                        geopotential_height_500hpa=5880 - (1008.5 - p) * 3, geopotential_height_850hpa=1510 - (1008.5 - p) * 8,
                        geopotential_height_925hpa=780 - (1008.5 - p) * 8.3)
            for n in names:
                data[n][ii, li, m] = vals[n]
dims = ("init_time", "lead_time", "ensemble_member", "latitude", "longitude")
ds = xr.Dataset({n: (dims, a) for n, a in data.items()},
                coords=dict(init_time=inits, lead_time=pd.to_timedelta(LEADS, unit="h"), ensemble_member=np.arange(M),
                            latitude=lat, longitude=lon))
ds.chunk({"init_time": 1, "lead_time": -1, "ensemble_member": -1, "latitude": 32, "longitude": 32}).to_zarr(out, mode="w")
print("fake AIFS store written to", out)
