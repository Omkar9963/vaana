#!/usr/bin/env bash
# End-to-end test on synthetic data: builds a fake WeatherNext run, ingests it, checks the output.
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=${TMP:-/tmp/vaana-test}
rm -rf "$TMP"; mkdir -p "$TMP"
python tests/make_fake_run.py "$TMP/wn" 2026092400
VAANA_SOURCE=weathernext WN_SFC_URL="$TMP/wn/sfc_{init:%Y%m%d%H}.zarr" \
WN_STN_URL="$TMP/wn/stn_{init:%Y%m%d%H}.zarr" \
WN_PL_URL="$TMP/wn/pl_{init:%Y%m%d%H}.zarr" \
VAANA_OUT="$TMP/out" HOURLY_UNTIL=24 MAX_LEAD=48 \
python -m vaana_ingest.run --init 2026092400
python - "$TMP/out" <<'PY'
import json, sys, os
out = sys.argv[1]
latest = json.load(open(f"{out}/latest.json"))
meta = json.load(open(f"{out}/runs/{latest['run']}/meta.json"))
tracks = json.load(open(f"{out}/runs/{latest['run']}/tracks.json"))
assert meta["storms"] >= 1, "tracker found no storm"
assert "rain_model" in meta["layers"] and "up_t_850" in meta["layers"], "layers missing"
n = sum(len(f) for _, _, f in os.walk(f"{out}/runs"))
print(f"OK: {len(meta['steps'])} steps, {len(meta['layers'])} layers, {meta['storms']} storm(s), {n} files")
PY
echo "== ECMWF AIFS ENS format"
python tests/make_fake_aifs.py "$TMP/aifs.zarr"
VAANA_SOURCE=aifs AIFS_URL="$TMP/aifs.zarr" VAANA_OUT="$TMP/out-aifs" python -m vaana_ingest.run
python - "$TMP/out-aifs" <<'PY'
import json, sys
out = sys.argv[1]
latest = json.load(open(f"{out}/latest.json"))
meta = json.load(open(f"{out}/runs/{latest['run']}/meta.json"))
assert latest["run"] == "2026092400", "should skip the incomplete newest run"
assert meta["model"]["source"] == "aifs" and meta["step_hours"] == 6 and meta["storms"] >= 1
print(f"OK: AIFS run {latest['run']}, {len(meta['steps'])} steps, {len(meta['layers'])} layers, {meta['storms']} storm(s)")
PY
echo "Open the website with ?data=<url of $TMP/out served over http> to view it."
