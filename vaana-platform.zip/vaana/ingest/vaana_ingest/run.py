"""Vaana ingest job.

Turns one WeatherNext 3 forecast run into:
  runs/<run>/f/<layer>/<hour>.bin   packed map grids (ensemble mean, chance, accumulations)
  runs/<run>/pt/<row>_<col>.bin     point-forecast tiles (percentiles per hour, daily totals)
  runs/<run>/tracks.json            cyclone tracks (median + every member)
  runs/<run>/strike.bin             cyclone strike chance grid
  runs/<run>/meta.json              description of everything above
  latest.json                       pointer to the newest complete run (written last)

Usage:  python -m vaana_ingest.run [--init 2026092400] [--force]
"""
import argparse
import datetime as dt
import logging
import math
import time

import numpy as np

from . import config as C
from .io import Writer, find_latest_init, grid_of, open_run, pack, pack_i16, var
from .tracker import Tracker

log = logging.getLogger("vaana")
DAYN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def unit_kind(key):
    if key.startswith("rain"):
        return "rain"
    if key in ("tcc", "hcc", "mcc", "lcc"):
        return "cloud"
    return key


def conv(key, a):
    """Source units to display units (°C, mm/h, W/m², hPa, % cloud)."""
    rule = C.UNITS[C.SOURCE].get(unit_kind(key))
    if not rule:
        return a
    op, v = rule
    return a + v if op == "add" else a * v


def conv_desc(key):
    rule = C.UNITS[C.SOURCE].get(unit_kind(key))
    if not rule:
        return ""
    op, v = rule
    if op == "add":
        return f" − {abs(v)}" if v < 0 else f" + {v}"
    return f" × {v:g}" if v >= 1 else f" ÷ {1 / v:g}"


def thr_code(t):
    return str(t).replace(".", "")


def run(init=None, force=False):
    t_start = time.time()
    W = Writer(C.OUT)
    aifs = C.SOURCE == "aifs"
    sfc_url = C.AIFS_URL if aifs else C.SFC_URL
    if not sfc_url:
        raise SystemExit("Set WN_SFC_URL (WeatherNext) or use VAANA_SOURCE=aifs.")
    sfc_vars = C.AIFS_SFC_VARS if aifs else C.SFC_VARS
    pl_vars = C.AIFS_PL if aifs else C.PL_VARS
    init = init or find_latest_init(sfc_url)
    run_id = init.strftime("%Y%m%d%H")
    latest = W.read_json("latest.json")
    if latest and latest.get("run") == run_id and not force:
        log.info("Run %s already published, nothing to do", run_id)
        return
    log.info("Processing run %s", run_id)

    sfc = open_run(sfc_url, init)
    sfc = sfc.sel(lead=[h for h in sfc.lead.values if 0 <= h <= C.MAX_LEAD])
    stn = open_run(C.STN_URL, init) if (C.STN_URL and not aifs) else None
    pl = sfc if aifs else (open_run(C.PL_URL, init) if C.PL_URL else None)
    if C.PRELOAD:
        keep = [v for v in sfc_vars.values() if v in sfc]
        if aifs:
            keep += [n.format(lev=l) for n in pl_vars.values() for l in C.LEVELS if n.format(lev=l) in sfc]
        log.info("Loading %d variables into memory", len(keep))
        sfc = sfc[keep].load()
        if aifs:
            pl = sfc
    g = grid_of(sfc)
    M = sfc.sizes["member"]
    ny, nx = g["ny"], g["nx"]
    leads = sorted(int(h) for h in sfc.lead.values if 0 <= h <= C.MAX_LEAD)
    steps = [h for h in leads if h <= C.HOURLY_UNTIL or h % C.STEP_AFTER == 0]
    stepset, sidx = set(steps), {h: i for i, h in enumerate(steps)}
    avail = {k: v for k, v in sfc_vars.items() if v in sfc}
    missing = sorted(set(sfc_vars) - set(avail))
    if missing:
        log.warning("Not in the surface store, skipped: %s", missing)
    rain_keys = [k for k in ("rain_model", "rain_imerg", "rain_exp") if k in avail]
    rk = "rain_model" if "rain_model" in rain_keys else rain_keys[0]
    base = f"runs/{run_id}"
    layers = {}

    def put(name, arr, kind, h, grid="sfc"):
        dtype, scale, off = C.PACK[kind]
        layers.setdefault(name, dict(grid=grid, dt=dtype, scale=scale, offset=off))
        W.put(f"{base}/f/{name}/{h}.bin", pack(arr, kind))

    # ---- rolling state
    open24 = {}                     # start hour -> per-member rain sum over (start, start+24]
    cum = {}                        # hour -> cumulative ensemble-mean rain since hour 0
    running = np.zeros((ny, nx), np.float64)
    day_acc, days, day_p50, day_chance = {}, [], [], []
    series = np.zeros((len(C.BLOCK_VARS), len(steps), ny, nx), np.int16)
    tracker = Tracker(g, M)

    def finish_chance(s, acc):
        for thr in C.CHANCE_THRESHOLDS:
            put(f"chance_{thr_code(thr)}", (acc >= thr).mean(0) * 100.0, "chance", s)

    def finish_day(key):
        acc, n, h0, h1 = day_acc.pop(key)
        if n < 12:
            return
        days.append(dict(label=f"{DAYN[key.weekday()]} {key.day}", h0=h0, h1=h1, partial=n < 24))
        day_p50.append(np.median(acc, 0))
        day_chance.append((acc >= 2.5).mean(0) * 100.0)

    prev_h = None
    step_hours = []
    for h in leads:
        dt_h = (h - prev_h) if prev_h is not None else 0
        prev_h = h
        if dt_h:
            step_hours.append(dt_h)
        full = h in stepset
        names = list(avail) if full else [rk]
        if h % C.TRACK_STEP == 0:
            names = list(dict.fromkeys(names + [k for k in ("mslp", "u10", "v10") if k in avail]))
        ds = sfc[[avail[k] for k in names]].sel(lead=h).load()
        A = {k: conv(k, ds[avail[k]].values.astype(np.float32)) for k in names}
        rain = np.maximum(np.nan_to_num(A[rk], nan=0.0), 0)     # mm/h, averaged over the step
        amt = rain * dt_h                                         # mm fallen during this step

        running += amt.mean(0)
        cum[h] = running.astype(np.float32).copy()
        for s in open24:
            if s < h <= s + 24:
                open24[s] += amt
        for s in [s for s in open24 if h >= s + 24]:
            finish_chance(s, open24.pop(s))
        if full and h < leads[-1]:
            open24[h] = np.zeros_like(rain)
        if dt_h:
            key = (init + dt.timedelta(hours=h - dt_h / 2 + C.IST_OFFSET_H)).date()
            for k in [k for k in day_acc if k != key]:
                finish_day(k)
            acc = day_acc.setdefault(key, [np.zeros_like(rain), 0, h, h])
            acc[0] += amt
            acc[1] += dt_h
            acc[3] = h

        if full:
            si = sidx[h]
            for k in rain_keys:
                put(k, np.maximum(A[k], 0).mean(0), "rain", h)       # NaN at hour 0 stays NaN (no rain yet)
            ws10 = np.hypot(A["u10"], A["v10"])
            put("ws10", ws10.mean(0), "wind", h)
            put("u10", A["u10"].mean(0), "uv", h)
            put("v10", A["v10"].mean(0), "uv", h)
            ws100 = None
            if "u100" in A and "v100" in A:
                ws100 = np.hypot(A["u100"], A["v100"])
                put("ws100", ws100.mean(0), "wind", h)
                put("u100", A["u100"].mean(0), "uv", h)
                put("v100", A["v100"].mean(0), "uv", h)
            for k in ("t2", "td2", "sst", "tcc", "lcc", "mcc", "hcc", "mslp", "ghi", "dir"):
                if k in A:
                    put(k, A[k].mean(0), C.LAYER_KIND[k], h)
            t2p = np.percentile(A["t2"], [10, 50, 90], axis=0)
            rp = np.percentile(rain, [10, 50, 90], axis=0) if dt_h else np.full((3, ny, nx), np.nan)
            wp = np.percentile(ws10 * 3.6, [10, 50, 90], axis=0)
            nanz = np.full((ny, nx), np.nan, np.float32)
            vals = {"t2_10": t2p[0], "t2_50": t2p[1], "t2_90": t2p[2], "rain_10": rp[0], "rain_50": rp[1], "rain_90": rp[2],
                    "ws_10": wp[0], "ws_50": wp[1], "ws_90": wp[2], "td2": A["td2"].mean(0) if "td2" in A else nanz,
                    "u10": A["u10"].mean(0), "v10": A["v10"].mean(0),
                    "ws100": ws100.mean(0) * 3.6 if ws100 is not None else nanz,
                    "mslp": A["mslp"].mean(0) if "mslp" in A else nanz, "tcc": A["tcc"].mean(0) if "tcc" in A else nanz,
                    "ghi": A["ghi"].mean(0) if "ghi" in A else nanz, "dir": A["dir"].mean(0) if "dir" in A else nanz}
            for vi, (name, scale) in enumerate(C.BLOCK_VARS):
                series[vi, si] = pack_i16(vals[name], scale)
        if h % C.TRACK_STEP == 0 and "mslp" in A:
            tracker.update(h, A["mslp"], np.hypot(A["u10"], A["v10"]))
        if h % 12 == 0:
            log.info("hour %d done (%.0f s)", h, time.time() - t_start)

    for s in list(open24):
        finish_chance(s, open24.pop(s))
    for k in list(day_acc):
        finish_day(k)

    # accumulations of the ensemble-mean rain (mean of sums == sum of means)
    last = leads[-1]
    step_typ = int(np.median(step_hours)) if step_hours else 1
    accum_hours = [n for n in C.ACCUM_HOURS if n >= step_typ]
    for s in steps:
        for n in accum_hours:
            end = min(s + n, last)
            end = max(x for x in cum if x <= end)
            put(f"accum{n}", cum[end] - cum[s], "accum", s)
    W.drain()

    # ---- station-trained 5 km temperature / dew point
    grids = {"sfc": g}
    srcvars = {}
    for k, v in avail.items():
        srcvars[k] = v + conv_desc(k)
    for n in ("10", "100"):
        if f"u{n}" in avail:
            srcvars[f"ws{n}"] = f"speed from {avail['u' + n]}, {avail['v' + n]}"
    for n in accum_hours:
        srcvars[f"accum{n}"] = f"sum of {avail[rk]} over each step"
    for t in C.CHANCE_THRESHOLDS:
        srcvars[f"chance_{thr_code(t)}"] = f"share of {M} members above {t} mm"
    if stn is not None:
        grids["stn"] = grid_of(stn)
        sv = {k: v for k, v in C.STN_VARS.items() if v in stn}
        for h in steps:
            if h not in stn.lead.values:
                continue
            ds = stn[list(sv.values())].sel(lead=h).load()
            for k, v in sv.items():
                put(k, conv(k, ds[v].values.astype(np.float32)).mean(0), "temp", h, "stn")
                srcvars[k] = v + conv_desc(k)
        W.drain()

    # ---- pressure levels (6-hourly runs only)
    levels, up_steps = [], []
    if pl is not None:
        grids["up"] = grid_of(pl)
        up_steps = [h for h in steps if h % C.UPPER_STEP == 0 and h in pl.lead.values]
        levels = [lev for lev in C.LEVELS if any(var(pl, n, lev) is not None for n in pl_vars.values())]
        kinds = {"u": "up_uv", "v": "up_uv", "t": "up_t", "z": "up_z", "q": "up_q", "w": "up_w"}
        units = C.UNITS[C.SOURCE]
        for h in up_steps:
            for lev in levels:
                for k, name in pl_vars.items():
                    da = var(pl, name, lev)
                    if da is None:
                        continue
                    a = da.sel(lead=h).values.astype(np.float32).mean(0)
                    rule = units.get(kinds[k])
                    if rule:
                        a = a + rule[1] if rule[0] == "add" else a * rule[1]
                    put(f"up_{k}_{lev}", a, kinds[k], h, "up")
                    srcvars[f"up_{k}_{lev}"] = (name.format(lev=lev) if "{lev}" in name else f"{name} at {lev} hPa") + (
                        (f" − {abs(rule[1])}" if rule[0] == "add" else f" × {rule[1]:g}" if rule[1] >= 1 else f" ÷ {1 / rule[1]:g}") if rule else "")
            W.drain()
            log.info("pressure levels hour %d done", h)

    # ---- cyclones
    sg = dict(lon0=C.DOMAIN["lon0"], lat1=C.DOMAIN["lat1"], d=0.25,
              nx=int(round((C.DOMAIN["lon1"] - C.DOMAIN["lon0"]) / 0.25)) + 1,
              ny=int(round((C.DOMAIN["lat1"] - C.DOMAIN["lat0"]) / 0.25)) + 1)
    storms, strike = tracker.finish(sg)
    grids["strk"] = sg
    W.put(f"{base}/strike.bin", pack(strike, "strike"))
    for s in storms:
        s.pop("member_ids", None)
    W.put_json(f"{base}/tracks.json", {"storms": storms})
    log.info("%d storm(s) tracked", len(storms))

    # ---- point-forecast tiles
    B = max(1, int(round(C.BLOCK_DEG / g["d"])))
    dp = np.array([pack_i16(a, C.BLOCK_DVARS[0][1]) for a in day_p50]) if days else np.zeros((0, ny, nx), np.int16)
    dc = np.array([pack_i16(a, C.BLOCK_DVARS[1][1]) for a in day_chance]) if days else np.zeros((0, ny, nx), np.int16)
    for bj in range(math.ceil(ny / B)):
        for bi in range(math.ceil(nx / B)):
            ys, xs = slice(bj * B, (bj + 1) * B), slice(bi * B, (bi + 1) * B)
            part = np.ascontiguousarray(series[:, :, ys, xs]).tobytes()
            part += np.ascontiguousarray(np.stack([dp[:, ys, xs], dc[:, ys, xs]])).tobytes()
            W.put(f"{base}/pt/{bj}_{bi}.bin", part)
    W.drain()

    meta = dict(
        run=run_id, init=init.strftime("%Y-%m-%dT%H:%M:00Z"), members=M, steps=steps, up_steps=up_steps,
        levels=levels, grids=grids, layers=layers,
        chance=C.CHANCE_THRESHOLDS, accum=accum_hours,
        rain_products=[k.split("_")[1] for k in rain_keys],
        block=dict(cells=B, vars=[n for n, _ in C.BLOCK_VARS], scales=[s for _, s in C.BLOCK_VARS],
                   dvars=[n for n, _ in C.BLOCK_DVARS], dscales=[s for _, s in C.BLOCK_DVARS],
                   nsteps=len(steps), ndays=len(days)),
        days=days, storms=len(storms),
        model=dict(C.MODEL_INFO[C.SOURCE], source=C.SOURCE),
        step_hours=int(np.median(step_hours)) if step_hours else 1,
        srcvars=srcvars,
        generated=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
    W.put_json(f"{base}/meta.json", meta)
    W.drain()
    W.put_json("latest.json", {"run": run_id, "init": meta["init"]}, cache="no-cache, max-age=0")
    W.drain()
    log.info("Published run %s: %d objects in %.0f s", run_id, W.count, time.time() - t_start)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--init", help="forecast run to process, e.g. 2026092400 (default: newest)")
    ap.add_argument("--force", action="store_true", help="process even if already published")
    a = ap.parse_args()
    init = dt.datetime.strptime(a.init, "%Y%m%d%H") if a.init else None
    run(init, a.force)


if __name__ == "__main__":
    main()
