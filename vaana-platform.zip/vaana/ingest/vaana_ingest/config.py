"""Settings for the Vaana ingest job. Everything can be overridden with environment variables."""
import os


def env(key, default):
    return os.environ.get(key, default)


# Map area: India, Bay of Bengal, Arabian Sea and neighbours.
DOMAIN = dict(lon0=55.0, lon1=105.0, lat0=-5.0, lat1=38.0)

# Which forecast model to process: "aifs" (ECMWF AIFS ENS, free, no approval) or "weathernext".
SOURCE = env("VAANA_SOURCE", "aifs")

# ECMWF AIFS ENS: one public store holding every run, opened through dynamical.org.
AIFS_URL = env("AIFS_URL", "dynamical:ecmwf-aifs-ens-forecast")

# Where WeatherNext 3 data lives. Fill these in once Google approves your access.
# Each value is either:
#   * a template containing {init:%Y%m%d%H} (one Zarr store per forecast run), or
#   * a single Zarr store that has an init-time dimension (the newest run is used).
# Run `python -m vaana_ingest.inspect <url>` first to see the real layout.
SFC_URL = env("WN_SFC_URL", "")      # 0.1 degree surface grid
STN_URL = env("WN_STN_URL", "")      # 0.05 degree station-trained temperature / dew point (optional)
PL_URL = env("WN_PL_URL", "")        # 0.25 degree pressure levels, 6-hourly runs only (optional)

# Output: a local folder or gs://bucket/prefix
OUT = env("VAANA_OUT", "./out")
GZIP = env("VAANA_GZIP", "1") == "1"          # gzip objects on GCS (browser decompresses automatically)

# Which forecast hours to publish.
MAX_LEAD = int(env("MAX_LEAD", "360"))          # 15 days
HOURLY_UNTIL = int(env("HOURLY_UNTIL", "72"))   # hourly steps for the first 3 days
STEP_AFTER = int(env("STEP_AFTER", "3"))        # then every 3 hours
UPPER_STEP = int(env("UPPER_STEP", "6"))        # pressure levels every 6 hours
TRACK_STEP = int(env("TRACK_STEP", "3"))        # cyclone tracker time step (hours)
SYNOPTIC_ONLY = env("SYNOPTIC_ONLY", "1") == "1"  # only 00/06/12/18 UTC runs (15-day range)

LEVELS = [1000, 925, 850, 700, 600, 500, 400, 300, 250, 200, 150, 100, 50]
CHANCE_THRESHOLDS = [2.5, 64.5, 115.6]           # mm in 24 h (IMD rain, heavy, very heavy)
ACCUM_HOURS = [3, 24, 72]
BLOCK_DEG = 1.0                                  # point-forecast tiles
IST_OFFSET_H = 5.5
UPLOAD_THREADS = int(env("UPLOAD_THREADS", "32"))

# Common alternative names for dimensions, checked in order.
ALIASES = {
    "member": ["ensemble_member", "member", "number", "sample", "realization", "ensemble"],
    "lead": ["lead_time", "prediction_timedelta", "step", "forecast_hour", "lead"],
    "lat": ["latitude", "lat"],
    "lon": ["longitude", "lon"],
    "level": ["level", "pressure_level", "isobaricInhPa", "plev"],
}
INIT_NAMES = ["init_time", "forecast_reference_time", "time"]

# WeatherNext 3 variable names (from the official model guide).
SFC_VARS = {
    "t2": "temperature_2m",
    "td2": "dewpoint_temperature_2m",
    "u10": "u_component_of_wind_10m",
    "v10": "v_component_of_wind_10m",
    "u100": "u_component_of_wind_100m",
    "v100": "v_component_of_wind_100m",
    "ghi": "surface_solar_radiation_downwards_1hr",
    "dir": "total_sky_direct_solar_radiation_at_surface_1hr",
    "rain_model": "total_precipitation_1hr",
    "rain_imerg": "imerg_tp_1hr",
    "rain_exp": "experimental_tp_1hr",
    "tcc": "total_cloud_cover",
    "hcc": "high_cloud_cover",
    "mcc": "medium_cloud_cover",
    "lcc": "low_cloud_cover",
    "mslp": "mean_sea_level_pressure",
    "sst": "sea_surface_temperature",
}
STN_VARS = {"t2s": "station_head_temperature_2m", "td2s": "station_head_dewpoint_temperature_2m"}
PL_VARS = {"u": "u_component_of_wind", "v": "v_component_of_wind", "t": "temperature",
           "z": "geopotential", "q": "specific_humidity", "w": "vertical_velocity"}

# ECMWF AIFS ENS variable names on dynamical.org (6-hourly, 0.25 degree, 51 members).
AIFS_SFC_VARS = {
    "t2": "temperature_2m",
    "td2": "dew_point_temperature_2m",
    "u10": "wind_u_10m",
    "v10": "wind_v_10m",
    "u100": "wind_u_100m",
    "v100": "wind_v_100m",
    "ghi": "downward_short_wave_radiation_flux_surface",
    "rain_model": "precipitation_surface",
    "tcc": "total_cloud_cover_atmosphere",
    "mslp": "pressure_reduced_to_mean_sea_level",
}
AIFS_PL = {"t": "temperature_{lev}hpa", "z": "geopotential_height_{lev}hpa"}   # only 850/925 (t), 500/850/925 (z)

# Units: how to turn each source's raw values into display units
# (°C, mm per hour, W/m², hPa, % cloud; pressure levels: °C, m, g/kg).
UNITS = {
    "weathernext": {"t2": ("add", -273.15), "td2": ("add", -273.15), "t2s": ("add", -273.15), "td2s": ("add", -273.15),
                    "sst": ("add", -273.15), "rain": ("mul", 1000.0), "ghi": ("mul", 1 / 3600), "dir": ("mul", 1 / 3600),
                    "mslp": ("mul", 0.01), "cloud": ("mul", 100.0),
                    "up_t": ("add", -273.15), "up_z": ("mul", 1 / 9.80665), "up_q": ("mul", 1000.0)},
    "aifs": {"rain": ("mul", 3600.0), "mslp": ("mul", 0.01)},
}
MODEL_INFO = {
    "weathernext": {"name": "WeatherNext 3", "by": "Google DeepMind",
                    "attribution": "Forecast data: Google DeepMind WeatherNext 3 (experimental)."},
    "aifs": {"name": "ECMWF AIFS ENS", "by": "ECMWF",
             "attribution": "ECMWF AIFS ENS forecast data processed by dynamical.org from ECMWF Open Data. CC BY 4.0."},
}
# Load the whole run into memory at once (needed for AIFS, whose storage chunks span all lead times).
PRELOAD = env("VAANA_PRELOAD", "1" if SOURCE == "aifs" else "0") == "1"

# How each published layer is packed: (dtype, scale, offset). value = raw * scale + offset
PACK = {
    "rain": ("u16", 0.01, 0.0), "accum": ("u16", 0.1, 0.0), "chance": ("u8", 1.0, 0.0),
    "wind": ("u16", 0.01, 0.0), "uv": ("i16", 0.01, 0.0), "temp": ("i16", 0.01, 0.0),
    "cloud": ("u8", 1.0, 0.0), "mslp": ("u16", 0.01, 800.0), "rad": ("u16", 0.1, 0.0),
    "up_uv": ("i16", 0.01, 0.0), "up_t": ("i16", 0.01, 0.0), "up_z": ("u16", 0.5, 0.0),
    "up_q": ("u16", 0.001, 0.0), "up_w": ("i16", 0.0005, 0.0), "strike": ("u8", 1.0, 0.0),
}
LAYER_KIND = {
    "rain_model": "rain", "rain_imerg": "rain", "rain_exp": "rain",
    "ws10": "wind", "ws100": "wind", "u10": "uv", "v10": "uv", "u100": "uv", "v100": "uv",
    "t2": "temp", "td2": "temp", "t2s": "temp", "td2s": "temp", "sst": "temp",
    "tcc": "cloud", "lcc": "cloud", "mcc": "cloud", "hcc": "cloud",
    "mslp": "mslp", "ghi": "rad", "dir": "rad",
}
# Point-forecast tile variables (int16, scale)
BLOCK_VARS = [("t2_10", 0.01), ("t2_50", 0.01), ("t2_90", 0.01), ("rain_10", 0.01), ("rain_50", 0.01),
              ("rain_90", 0.01), ("ws_10", 0.01), ("ws_50", 0.01), ("ws_90", 0.01), ("td2", 0.01),
              ("u10", 0.01), ("v10", 0.01), ("ws100", 0.01), ("mslp", 0.1), ("tcc", 0.01),
              ("ghi", 0.1), ("dir", 0.1)]
BLOCK_DVARS = [("rain_day_50", 0.1), ("rain_day_chance", 0.01)]
