"""Reading WeatherNext 3 Zarr stores and writing packed output (local folder or GCS)."""
import datetime as dt
import gzip
import json
import os
import threading
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import xarray as xr

from . import config as C

# ---------------------------------------------------------------- reading


def _open_any(url):
    if url.startswith("dynamical:"):
        import dynamical_catalog
        return dynamical_catalog.open(url.split(":", 1)[1], chunks={})
    return xr.open_zarr(url, chunks={})


def _url(template, init):
    return template.format(init=init) if "{init" in template else template


def store_exists(template, init):
    import fsspec
    url = _url(template, init)
    fs, path = fsspec.core.url_to_fs(url)
    return any(fs.exists(f"{path}/{m}") for m in ("zarr.json", ".zmetadata", ".zgroup"))


def find_latest_init(template, now=None, lookback_h=36):
    """Newest forecast run that exists. Works for both per-run templates and single stores."""
    now = now or dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
    if "{init" not in template:
        ds = _open_any(template)
        for name in C.INIT_NAMES:
            if name in ds.dims and np.issubdtype(ds[name].dtype, np.datetime64):
                inits = ds[name].values
                probe = next(v for v in ds.data_vars if "lead_time" in ds[v].dims or "lead" in ds[v].dims)
                lead_dim = "lead_time" if "lead_time" in ds[probe].dims else "lead"
                # newest run whose final lead time has data (skips a run that is still being written)
                for k in range(len(inits) - 1, max(-1, len(inits) - 6), -1):
                    pt = ds[probe].isel({name: k, lead_dim: -1}).isel({d: 0 for d in ds[probe].dims if d not in (name, lead_dim)})
                    if np.isfinite(pt.values):
                        return dt.datetime.utcfromtimestamp(inits[k].astype("datetime64[s]").astype(int))
                raise RuntimeError("No complete run found among the latest inits")
        raise RuntimeError("Could not find an init-time dimension in " + template)
    step = 6 if C.SYNOPTIC_ONLY else 1
    t = now.replace(minute=0, second=0, microsecond=0)
    t -= dt.timedelta(hours=t.hour % step)
    for _ in range(lookback_h // step + 1):
        if store_exists(template, t):
            return t
        t -= dt.timedelta(hours=step)
    raise RuntimeError("No forecast run found in the last %d hours" % lookback_h)


def canon(ds, init):
    """Rename dimensions to member/lead/lat/lon(/level), pick the run, subset to the domain, north-up."""
    ren = {}
    for canonical, aliases in C.ALIASES.items():
        for a in aliases:
            if a in ds.dims:
                if a != canonical:
                    ren[a] = canonical
                break
    ds = ds.rename(ren)
    for name in C.INIT_NAMES:
        if name in ds.dims:
            if np.issubdtype(ds[name].dtype, np.datetime64):
                ds = ds.sel({name: np.datetime64(init)}, method="nearest")
            elif np.issubdtype(ds[name].dtype, np.timedelta64) and "lead" not in ds.dims:
                ds = ds.rename({name: "lead"})
    if "member" not in ds.dims:
        ds = ds.expand_dims(member=[0])
    lead = ds["lead"].values
    hours = (lead / np.timedelta64(1, "h")).round().astype(int) if np.issubdtype(lead.dtype, np.timedelta64) else np.asarray(lead).astype(int)
    ds = ds.assign_coords(lead=hours)
    lon = ds["lon"].values
    if lon.max() > 180 and C.DOMAIN["lon0"] < 0:
        ds = ds.assign_coords(lon=((ds.lon + 180) % 360) - 180).sortby("lon")
    D = C.DOMAIN
    lat = ds["lat"].values
    lat_sl = slice(D["lat1"], D["lat0"]) if lat[0] > lat[-1] else slice(D["lat0"], D["lat1"])
    ds = ds.sel(lat=lat_sl, lon=slice(D["lon0"], D["lon1"]))
    if ds.lat.values[0] < ds.lat.values[-1]:
        ds = ds.isel(lat=slice(None, None, -1))
    return ds.transpose("member", "lead", ..., "lat", "lon", missing_dims="ignore")


def open_run(template, init):
    if not template:
        return None
    return canon(_open_any(_url(template, init)), init)


def grid_of(ds):
    lat, lon = ds.lat.values, ds.lon.values
    return dict(lon0=round(float(lon[0]), 4), lat1=round(float(lat[0]), 4),
                d=round(float(abs(lat[1] - lat[0])), 5), nx=int(lon.size), ny=int(lat.size))


def var(ds, name, level=None):
    """Find a variable, including flattened pressure-level names like geopotential_500 or temperature_{lev}hpa."""
    if level is not None and "{lev}" in name:
        flat = name.format(lev=level)
        return ds[flat] if flat in ds else None
    if level is not None:
        if name in ds and "level" in ds[name].dims:
            return ds[name].sel(level=level)
        flat = f"{name}_{level}"
        return ds[flat] if flat in ds else None
    return ds[name] if name in ds else None


# ---------------------------------------------------------------- packing

SENTINEL = {"u8": 255, "u16": 65535, "i16": -32768}
NPTYPE = {"u8": np.uint8, "u16": np.uint16, "i16": np.int16}
LIMITS = {"u8": (0, 254), "u16": (0, 65534), "i16": (-32767, 32767)}


def pack(arr, kind):
    dtype, scale, offset = C.PACK[kind]
    a = np.asarray(arr, dtype=np.float64)
    raw = np.round((a - offset) / scale)
    lo, hi = LIMITS[dtype]
    raw = np.clip(np.nan_to_num(raw, nan=lo), lo, hi).astype(NPTYPE[dtype])
    raw[~np.isfinite(a)] = SENTINEL[dtype]
    return raw.tobytes()


def pack_i16(arr, scale):
    a = np.asarray(arr, dtype=np.float64)
    raw = np.clip(np.round(np.nan_to_num(a, nan=0) / scale), -32767, 32767).astype(np.int16)
    raw[~np.isfinite(a)] = -32768
    return raw


# ---------------------------------------------------------------- writing


class Writer:
    """Writes objects to a local folder or to Google Cloud Storage in parallel."""

    def __init__(self, base):
        self.base = base.rstrip("/")
        self.gcs = base.startswith("gs://")
        self.s3 = base.startswith("s3://")
        self.pool = ThreadPoolExecutor(C.UPLOAD_THREADS)
        self.futures = []
        self.lock = threading.Lock()
        self.count = 0
        if self.gcs:
            from google.cloud import storage
            bucket, _, prefix = self.base[5:].partition("/")
            self.bucket = storage.Client().bucket(bucket)
            self.prefix = prefix
        if self.s3:
            # Any S3-compatible store, e.g. Cloudflare R2 (set S3_ENDPOINT, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
            import boto3
            bucket, _, prefix = self.base[5:].partition("/")
            self.s3c = boto3.client("s3", endpoint_url=os.environ.get("S3_ENDPOINT") or None,
                                    region_name=os.environ.get("S3_REGION", "auto"))
            self.bucket, self.prefix = bucket, prefix

    def _key(self, rel):
        return f"{self.prefix}/{rel}" if self.prefix else rel

    def _put(self, rel, data, content_type, cache):
        if self.s3:
            extra = {"ContentType": content_type, "CacheControl": cache}
            if C.GZIP:
                extra["ContentEncoding"] = "gzip"
                data = gzip.compress(data, 6)
            self.s3c.put_object(Bucket=self.bucket, Key=self._key(rel), Body=data, **extra)
        elif self.gcs:
            name = self._key(rel)
            blob = self.bucket.blob(name)
            blob.cache_control = cache
            if C.GZIP:
                blob.content_encoding = "gzip"
                data = gzip.compress(data, 6)
            blob.upload_from_string(data, content_type=content_type)
        else:
            path = os.path.join(self.base, rel)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
        with self.lock:
            self.count += 1

    def put(self, rel, data, content_type="application/octet-stream", cache="public, max-age=86400, immutable"):
        self.futures.append(self.pool.submit(self._put, rel, data, content_type, cache))
        if len(self.futures) > 400:
            self.drain()

    def put_json(self, rel, obj, cache="public, max-age=86400, immutable"):
        self.put(rel, json.dumps(obj, separators=(",", ":")).encode(), "application/json", cache)

    def drain(self):
        for f in self.futures:
            f.result()
        self.futures = []

    def read_json(self, rel):
        try:
            if self.s3:
                body = self.s3c.get_object(Bucket=self.bucket, Key=self._key(rel))["Body"].read()
                try:
                    body = gzip.decompress(body)
                except OSError:
                    pass
                return json.loads(body)
            if self.gcs:
                name = f"{self.prefix}/{rel}" if self.prefix else rel
                return json.loads(self.bucket.blob(name).download_as_bytes())
            with open(os.path.join(self.base, rel)) as f:
                return json.load(f)
        except Exception:
            return None
