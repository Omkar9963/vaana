"""Print the layout of a WeatherNext Zarr store so config.py can be checked.

Usage:  python -m vaana_ingest.inspect gs://<bucket>/<path-to-store>
"""
import sys

import xarray as xr


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    ds = xr.open_zarr(sys.argv[1], chunks={})
    print(ds)
    print("\nDimensions:", dict(ds.sizes))
    for name in ds.dims:
        v = ds[name].values
        print(f"  {name}: {v.dtype} first={v[:3]} last={v[-3:]}")
    print("\nVariables:")
    for name, da in ds.data_vars.items():
        print(f"  {name}{tuple(da.dims)}  units={da.attrs.get('units', '?')}")


if __name__ == "__main__":
    main()
