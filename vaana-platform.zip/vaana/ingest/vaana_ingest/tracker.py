"""Simple tropical-cyclone tracker for ensemble forecasts.

For every ensemble member it finds sea-level pressure minima with a closed low and strong
surrounding wind, links them in time, then groups matching tracks from different members
into storms. Output: median track, member tracks and strike probability.
"""
import numpy as np
from scipy import ndimage

P_MAX = 1004.0      # hPa, candidate centre must be below this
DEPTH = 2.0         # hPa below the surrounding 6x6 degree mean
V_MIN = 12.0        # m/s, max 10 m wind within ~2 degrees
KEEP_V = 14.0       # m/s, a track must reach this at least once
MIN_POINTS = 4


def _dist(x1, y1, x2, y2):
    cl = np.cos(np.radians((y1 + y2) / 2))
    return np.hypot((x1 - x2) * cl, y1 - y2)


class Tracker:
    def __init__(self, grid, members):
        self.g = grid
        self.k = max(1, int(round(0.25 / grid["d"])))           # work on ~0.25 degree
        self.d = grid["d"] * self.k
        self.members = members
        self.active = [[] for _ in range(members)]              # list of open tracks per member
        self.done = [[] for _ in range(members)]
        self.last_h = None

    def _coarse(self, a):
        k = self.k
        if k == 1:
            return a
        ny, nx = a.shape[-2] // k * k, a.shape[-1] // k * k
        a = a[..., :ny, :nx]
        return a.reshape(*a.shape[:-2], ny // k, k, nx // k, k).mean(axis=(-3, -1))

    def update(self, h, mslp_hpa, wind_ms):
        """mslp_hpa, wind_ms: arrays (member, ny, nx) on the surface grid."""
        P = self._coarse(np.nan_to_num(mslp_hpa, nan=1013.0))
        V = self._coarse(np.nan_to_num(wind_ms, nan=0.0))
        win = max(3, int(round(2.0 / self.d)) | 1)
        box = max(5, int(round(6.0 / self.d)) | 1)
        dt = (h - self.last_h) if self.last_h is not None else 3
        maxd = min(3.0, 0.3 * dt + 0.6)
        lon0, lat1 = self.g["lon0"] + (self.k - 1) * self.g["d"] / 2, self.g["lat1"] - (self.k - 1) * self.g["d"] / 2
        for m in range(P.shape[0]):
            ps = ndimage.uniform_filter(P[m], 3)
            cand = (ps == ndimage.minimum_filter(ps, win)) & (ps < P_MAX)
            cand &= (ndimage.uniform_filter(ps, box) - ps) >= DEPTH
            vmax = ndimage.maximum_filter(V[m], win)
            cand &= vmax >= V_MIN
            jj, ii = np.nonzero(cand)
            pts = [(lon0 + i * self.d, lat1 - j * self.d, float(ps[j, i]), float(vmax[j, i])) for j, i in zip(jj, ii)]
            pts = [p for p in pts if 2.0 < p[1] < 32.0]
            used, keep = set(), []
            pairs = sorted(((_dist(t[-1][1], t[-1][2], p[0], p[1]), ti, pi)
                            for ti, t in enumerate(self.active[m]) for pi, p in enumerate(pts)), key=lambda x: x[0])
            matched = set()
            for d, ti, pi in pairs:
                if d > maxd or ti in matched or pi in used:
                    continue
                matched.add(ti); used.add(pi)
                self.active[m][ti].append((h, *pts[pi]))
            for ti, t in enumerate(self.active[m]):
                (keep if ti in matched else self.done[m]).append(t)
            for pi, p in enumerate(pts):
                if pi not in used:
                    keep.append([(h, *p)])
            self.active[m] = keep
        self.last_h = h

    def finish(self, strike_grid):
        tracks = []
        for m in range(self.members):
            for t in self.done[m] + self.active[m]:
                if len(t) >= MIN_POINTS and max(p[4] for p in t) >= KEEP_V:
                    tracks.append((m, t))
        tracks.sort(key=lambda mt: -max(p[4] for p in mt[1]))
        clusters = []
        for m, t in tracks:
            td = {p[0]: p for p in t}
            best, bestd = None, 3.0
            for c in clusters:
                ref = c["ref"]
                common = [h for h in td if h in ref]
                if len(common) < 2:
                    continue
                d = np.mean([_dist(td[h][1], td[h][2], ref[h][1], ref[h][2]) for h in common])
                if d < bestd:
                    best, bestd = c, d
            if best is None:
                clusters.append({"ref": td, "members": {m: t}})
            elif m not in best["members"] or len(best["members"][m]) < len(t):
                best["members"][m] = t
        need = max(2, int(0.2 * self.members))
        storms = []
        for c in clusters:
            if len(c["members"]) < need:
                continue
            hours = sorted({p[0] for t in c["members"].values() for p in t})
            med = []
            for h in hours:
                ps = [p for t in c["members"].values() for p in t if p[0] == h]
                if len(ps) >= max(2, 0.3 * self.members):
                    a = np.array([p[1:] for p in ps])
                    med.append([int(h), *[round(float(v), 2) for v in np.median(a, axis=0)]])
            if len(med) < MIN_POINTS:
                continue
            lon_mean = np.mean([p[1] for p in med])
            storms.append({
                "id": len(storms) + 1,
                "basin": "Arabian Sea" if lon_mean < 77 else "Bay of Bengal",
                "members": len(c["members"]),
                "member_ids": [int(k) for k in c["members"].keys()],
                "median": med,
                "tracks": [[[int(p[0]), round(p[1], 2), round(p[2], 2), round(p[3], 1), round(p[4], 1)] for p in t]
                           for t in c["members"].values()],
            })
        return storms, self._strike(storms, strike_grid)

    def _strike(self, storms, g):
        lon = g["lon0"] + np.arange(g["nx"]) * g["d"]
        lat = g["lat1"] - np.arange(g["ny"]) * g["d"]
        LON, LAT = np.meshgrid(lon, lat)
        cl = np.cos(np.radians(LAT))
        hits = np.zeros((self.members, g["ny"], g["nx"]), bool)
        for s in storms:
            for m, t in zip(s["member_ids"], s["tracks"]):
                for h, x, y, p, v in t:
                    if v < 8.7:
                        continue
                    j0, j1 = np.searchsorted(-lat, [-(y + 1.2), -(y - 1.2)])
                    i0, i1 = np.searchsorted(lon, [x - 1.5, x + 1.5])
                    sub = np.hypot((LON[j0:j1, i0:i1] - x) * cl[j0:j1, i0:i1], LAT[j0:j1, i0:i1] - y) <= 1.0
                    hits[m, j0:j1, i0:i1] |= sub
        return hits.sum(0) / self.members * 100.0
