# Vaana: AI weather platform for India

Vaana (వాన, "rain") is a Windy-style weather website for India and the surrounding seas. It runs on **ECMWF AIFS ENS**, the European weather centre's AI ensemble forecast, which is free and open under CC BY 4.0 with no approval needed. It is also ready for **Google WeatherNext 3** once access is granted; switching is one setting.

```
ECMWF AIFS ENS (free, via dynamical.org on AWS)
        │  every 1–2 hours a scheduler starts the job
        ▼
Ingest job (Python)  ──►  Data storage (Cloudflare R2 or Google Cloud Storage)
  • crops to 55–105°E, 5°S–38°N        runs/<run>/f/…        map layers
  • ensemble mean, percentiles         runs/<run>/pt/…       point forecasts
  • chance of rain, rain totals        runs/<run>/tracks.json  cyclones
  • cyclone tracker                    latest.json           newest run
        ▲
        │  the browser downloads only what it shows
Website (one static HTML page + config.js)
```

There is no database and no always-on server. The job writes files and the website reads them.

## What the ECMWF version shows

| | ECMWF AIFS ENS |
|---|---|
| Members | 51 |
| Grid | 0.25° (about 28 km) |
| Steps | Every 6 hours, up to 15 days |
| Runs | 00, 06, 12 and 18 UTC |

**Map layers**
- Rain rate (6-hour average) and rain totals over 24 hours and 3 days.
- Chance of 2.5, 64.5 and 115.6 mm of rain in 24 hours.
- Wind at 10 m and 100 m, with animated flow.
- Temperature, dew point, relative humidity and feels-like temperature.
- Total cloud, solar radiation and sea-level pressure with isobars.
- Temperature at 850 and 925 hPa, and geopotential height at 500, 850 and 925 hPa.
- Cyclone tracks with IMD categories, landfall timing and strike chance.

**Point forecast**
- Click any place for a 15-day chart with the ensemble range and a daily summary.

**Not available in AIFS, but shown automatically once WeatherNext 3 is connected**
- Hourly steps.
- Low, medium and high cloud.
- Sea surface temperature.
- Upper-air wind.

## Folder layout

| Path | What it is |
|---|---|
| `ingest/vaana_ingest/run.py` | The ingest job |
| `ingest/vaana_ingest/config.py` | All settings: model choice, variable names, units, forecast hours |
| `ingest/vaana_ingest/tracker.py` | Cyclone tracker |
| `ingest/vaana_ingest/io.py` | Reading models; writing to a folder, Google Cloud Storage or any S3-compatible store (R2) |
| `ingest/tests/` | Synthetic data in both model formats and an end-to-end test |
| `frontend/` | Website source (`src/`) and `build.py`, which writes `dist/index.html` and `dist/config.js` |
| `.github/workflows/ingest.yml` | Free hosting route: runs the job on GitHub Actions |
| `deploy/` | Google Cloud route: setup scripts |

## Step 1. Try it on your computer

You need Python 3.11 or newer.

```bash
cd ingest
pip install -r requirements.txt
bash tests/test_pipeline.sh                 # synthetic test, no internet data needed

# one real ECMWF run into a local folder (downloads about 1 GB, takes a few minutes)
VAANA_SOURCE=aifs VAANA_OUT=./out python -m vaana_ingest.run

cd ../frontend && python build.py
cd dist && ln -s ../../ingest/out data && python -m http.server 8080
# open http://localhost:8080/?data=http://localhost:8080/data
```

On Windows, copy `ingest/out` into `frontend/dist/data` instead of using `ln -s`.

The top bar should read "Live ECMWF AIFS ENS data, 51 members", and the timeline opens at the current time. Without `?data=` the site shows its built-in demo.

## Step 2, route A. Free hosting (GitHub + Cloudflare)

This route costs nothing for normal use. GitHub Actions runs the job for free in public repositories. Cloudflare R2 stores the data with free downloads. Cloudflare Pages hosts the website.

1. **Code.** Put this folder in a GitHub repository. Public is simplest, because Actions minutes are free for public repositories.
2. **Storage bucket.** In Cloudflare, go to R2 and create a bucket, for example `vaana-data`.
3. **Public access.** Under the bucket's *Settings*, turn on public access. Either enable the r2.dev address or connect your own domain, for example `data.yourdomain.org`.
4. **CORS.** Under *Settings → CORS policy*, add this, replacing the origin with your site address:
   ```json
   [{"AllowedOrigins":["https://vaana.pages.dev"],"AllowedMethods":["GET","HEAD"],"AllowedHeaders":["*"],"ExposeHeaders":["Content-Encoding"],"MaxAgeSeconds":3600}]
   ```
5. **Auto-delete.** Under *Settings → Object lifecycle rules*, delete objects with prefix `runs/` after 3 days.
6. **API token.** Create an R2 API token with *Object Read & Write* on the bucket. Note the access key ID, the secret and the S3 endpoint (`https://<account-id>.r2.cloudflarestorage.com`).
7. **Repository secrets.** In the GitHub repository, go to *Settings → Secrets and variables → Actions* and add `R2_BUCKET`, `R2_ENDPOINT`, `R2_ACCESS_KEY_ID` and `R2_SECRET_ACCESS_KEY`.
8. **First run.** Go to *Actions → vaana-ingest → Run workflow*. After that it runs every 2 hours and skips runs that are already published.
9. **Website.** Run `python frontend/build.py`, then edit `frontend/dist/config.js`:
   ```js
   window.VAANA_CONFIG = { dataUrl: 'https://<your public R2 address>' };
   ```
   In Cloudflare go to *Workers & Pages → Create → Pages → Upload assets* and upload the `frontend/dist` folder, excluding `vaana-demo.html` if you like. GitHub Pages also works.

## Step 2, route B. Google Cloud

Use this route if RySS prefers everything on Google Cloud, or for WeatherNext later. It is billed but small for AIFS.

1. Edit `deploy/settings.env`: project ID, bucket name and site address. Keep `VAANA_SOURCE="aifs"`.
2. Run `bash deploy/setup_gcp.sh`. It creates the bucket, a Cloud Run job (4 CPU / 16 GB) and an hourly schedule in the Mumbai region.
3. Run the first job: `gcloud run jobs execute vaana-ingest --region asia-south1 --wait`.
4. Deploy the site: `bash deploy/deploy_site.sh`. It publishes to Firebase Hosting.

For AIFS, the job itself should cost only a few US dollars a month. Download traffic grows with the number of visitors. Check the Google Cloud pricing calculator for your expected use.

## Licence and attribution (required)

ECMWF open data is licensed under CC BY 4.0 and the ECMWF Terms of Use. It may be shared and used commercially if the source is credited. The website shows the required credit on every screen: *"ECMWF AIFS ENS forecast data processed by dynamical.org from ECMWF Open Data. CC BY 4.0."* Keep this line if you change the design.

AI forecasts are experimental and are not official warnings. The site tells users to follow IMD for official warnings.

## Adding WeatherNext 3 later

1. When Google approves access, run `python -m vaana_ingest.inspect <store url>` and check the names in `config.py`.
2. Set `VAANA_SOURCE=weathernext` and `WN_SFC_URL` (plus `WN_STN_URL` and `WN_PL_URL` if available).
3. Give the job more resources: 8 CPU and 32 GB, with a 3-hour timeout. WeatherNext is about 10 km, hourly and has 64 members.
4. Confirm with Google whether a public website may show its real-time data.

The website adapts by itself: it shows hourly steps, the extra layers and the new model name. To offer both models side by side, run the job twice into two prefixes (for example `aifs/` and `weathernext/`) and host two copies of the site. A model switcher inside one page is a natural next feature.

## Things to check with the first real runs

1. **Data layout.** The job reads dynamical.org's dataset through the `dynamical-catalog` package. If they change variable names, update `AIFS_SFC_VARS` in `config.py`.
2. **Rain.** Compare with IMD and APSDPS rain gauges for a few districts. A 28 km model smooths local heavy showers, so expect lower peaks than station totals.
3. **Temperature extremes.** Daily highs and lows are approximate, because the 6-hour steps (05:30, 11:30, 17:30 and 23:30 IST) miss the afternoon peak. The site says so in the point panel.
4. **Cyclone tracker.** The thresholds in `tracker.py` are tuned for 0.25° data. Check them against a past Bay of Bengal storm from the dataset archive, which starts July 2025.

## Ideas for later

- Telugu and Hindi interface.
- District and mandal pages using IMD rainfall categories.
- WhatsApp or SMS alerts for heavy rain and cyclones.
- Installable offline app (PWA) for field staff.
- Model comparison: AIFS, WeatherNext and NOAA GFS.
